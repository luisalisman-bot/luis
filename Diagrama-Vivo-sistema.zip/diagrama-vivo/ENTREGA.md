# Estado de la entrega

Sistema creado: seis skills, biblioteca canvas reutilizable, anclas por palabras, cámara, subtítulos opcionales, voz REST o manual, transcripción, efectos, mezcla de dos pasadas, QA e instrucciones.

**Pruebas de código: 13 aprobadas.** La prueba de mezcla usa tono sintético y ASR simulado: valida el mezclador, no demuestra reconocimiento de voz.

**Preview gráfica:** 10 s, 1080×1920, 30 fps, 300 frames. Decodificación completa sin errores; hoja revisada de 20 frames, a 2 fps. Sin voz y con anclas de fixture identificadas. No es un vídeo final.

**QA de la prueba narrada: NO APROBADO / PENDIENTE.** ElevenLabs no inició la generación por saturación gratuita y no cobró. La red negó la descarga de Whisper small desde Hugging Face. Faltan narración, alineación real ≥98%, mezcla real, transcripción del MP4 y revisión audiovisual. No se ha declarado cumplida esa parte.

Comenzar en README.md. Aportar voz.wav o generar con ElevenLabs cuando esté disponible; instalar modelo small o indicarlo por ruta local; seguir los comandos documentados. El primer corto completo se produce después de aprobar la prueba y elegir su tema.

No contiene claves, paquetes instalados ni modelos pesados. Incluye lockfile, requisitos, código, seis SKILL.md, prueba gráfica, hojas de contacto, registros y hashes. No se publicó en TikTok.
