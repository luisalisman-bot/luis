# Diagrama Vivo · sistema reutilizable

Motor de dibujo técnico vertical, seis skills y pipeline local. Esta entrega incluye una prueba **muda y provisional**, no un vídeo final aprobado. La narración ElevenLabs no se pudo iniciar por saturación del servicio gratuito (sin cobro); la red del entorno bloqueó Hugging Face y por tanto la descarga de Whisper small. No se han inventado tiempos de voz ni aprobado QA de narración.

## Inicio

Requisitos: Node 22+, Python 3.11+, FFmpeg y ffprobe con libx264, loudnorm, sidechaincompress. Ejecutar desde esta carpeta:

```bash
bash prod/setup.sh
```

El setup instala npm con lockfile, crea `.venv` e instala Python. La última línea descarga Whisper small, requiere acceso a `huggingface.co` y su CDN. Alternativa: copiar un modelo small convertido a CTranslate2 desde otra máquina y usar `--model /ruta/local` o `WHISPER_MODEL=/ruta/local`. El modelo de prueba no se distribuye en este ZIP.

## Producción

1. Preparar y revisar `guion.txt`: cabecera PIEZA ÁMBAR, luego narración de 110–160 palabras. El guion incluido es una prueba de 20 palabras, no un corto completo. Adaptar `escenas/bolita.json`: duración real, anclas por frase, poses, cámara y efectos.
2. Proveer `voz.wav` manualmente, o configurar ELEVENLABS_API_KEY en el entorno y ejecutar `.venv/bin/python prod/pipeline.py tts`. Voz fija seleccionada: Arturo Tutorias; configuración en `voice.json`. No incluir la clave en archivos ni en Git. La voz original se conserva; no hay cambio de tempo ni recorte.
3. `.venv/bin/python prod/pipeline.py sync --model small` → `words.json`, `transcript.txt` y diff. Coincidencia ≥98% por WER, sin forzar reconocimiento con el guion.
4. `node prod/render.mjs` → frames PNG e `imagen.mp4`. Subtítulos opcionales: añadir `--captions`; no cambia el audio ni los eventos.
5. `.venv/bin/python prod/pipeline.py mix` → `salida.mp4`, efectos originales y registros de las dos pasadas loudnorm.
6. `.venv/bin/python prod/pipeline.py qa --model small` → informe y hojas completas a 2 fps. La primera ejecución falla hasta registrar la revisión visual/auditiva real con el hash del MP4. Ver `skills/qa-video-final/SKILL.md`; después repetir QA. Nunca completar revisión sin inspeccionar el vídeo y todas las hojas.
7. `.venv/bin/python prod/pipeline.py publish` → borrador de copia para TikTok. No publica nada.

Atajo: `bash prod/build.sh`; para la prueba corta con voz real: `bash prod/build.sh --demo`. Se detiene en la primera puerta fallida. Para revisar tras un fallo de QA no es necesario repetir render: ejecutar QA de nuevo después de resolver la causa. Para producción completa configurar 45–90 s; el tema del primer vídeo queda pendiente de tu elección.

## Prueba gráfica de 10 segundos

```bash
node prod/render.mjs --fixture-preview
.venv/bin/python prod/pipeline.py qa --video preview-mudo.mp4
```

`tests/words.fixture.json` contiene tiempos SINTÉTICOS exclusivamente para probar código. La preview no lleva voz ni pretende demostrar sincronía palabra-acción. El renderer de producción rechaza esta fixture. La QA sobre esta preview debe fallar en audio, transcripción, procedencia de voz y revisión de sincronía. Ver informe incluido; un render que termina correctamente no implica aprobación.

## Arquitectura y extensión

- `prod/draw.mjs`: paleta exacta, fuentes Fontsource, pines, rueda dentada, carrete con muelle, correa, copa/bola/palanca/garra, figura de líneas, etiquetas y subtítulos.
- `prod/timeline.mjs`: búsqueda por frases, detección de ambigüedad, tiempos desde palabras, interpolación pura, estado independiente del orden de render y cierre de bucle.
- `prod/render.mjs`: PNG a 1080×1920, 30 fps, H.264. Compila anclas y registra `qa/timeline.json`.
- `prod/pipeline.py`: guion, TTS REST/manual, Whisper, WER, SRT, efectos deterministas, ducking, mezcla en dos pasadas, decodificación completa, hoja paginada, loudness, procedencia y QA.
- `skills/*/SKILL.md`: los seis procedimientos reutilizables, instalables como skills de Claude Code copiando cada carpeta a `.claude/skills/` del proyecto de destino.

Para añadir otro mecanismo se debe dibujar su geometría y declarar sus poses/acciones. El motor reutiliza primitivas, anclas, cámara, mezcla y QA; no inventa mecanismos arbitrarios ni convierte cualquier texto en animación automáticamente. El esquema representa el principio de un sensor de bola sensible al vehículo; las geometrías reales de retractores varían y este dibujo no es un plano homologado.

La acción respeta x40–920 y y90–1570; subtítulos hasta y1640. Margen derecho de 160 px y últimos 250 px libres. Solo la bola usa ámbar. La palabra activa de los subtítulos se distingue por luminosidad y pop para preservar la exclusividad del ámbar. Cámara y fases vuelven al inicio al final del bucle; la continuidad de voz se validará con el audio definitivo.

## Verificación del código

```bash
npm test
.venv/bin/python -m unittest discover -s tests -v
```

Pruebas: cambios de voz desplazan eventos, anclas ambiguas/ausentes fallan, duraciones cortas fallan, datos temporales inválidos fallan, estado determinista, retorno del bucle, omisiones/inserciones/repeticiones de texto. La inspección de contacto es humana y no se sustituye por estos tests.

Dependencias fijadas en `package-lock.json` y `requirements.txt`. Fuentes Anton, Barlow Condensed y Montserrat distribuidas por Fontsource bajo SIL OFL; licencias en sus paquetes npm tras instalar. Efectos sintetizados por el código, sin librerías externas. La voz queda sujeta a los términos de ElevenLabs. Código del sistema entregado para su uso y modificación; no se asigna una licencia a servicios de terceros.
