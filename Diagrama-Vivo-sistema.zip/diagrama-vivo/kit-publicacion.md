# La bolita que bloquea el cinturón

Una bolita puede activar el bloqueo de tu cinturón.

Así funciona un sensor inercial de bola en un retractor: la bola desplaza una palanca y permite que la garra frene el carrete. Esquema didáctico; el diseño varía según el modelo.

¿Qué otra pieza pequeña quieres ver por dentro?

#Ingenieria #ComoFunciona #Mecanismos #DiagramaVivo
