#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${DIAGRAMA_PYTHON:-.venv/bin/python}"
"$PYTHON" prod/pipeline.py script "$@"
# voz.wav must exist; generating/replacing narration is an explicit separate command.
"$PYTHON" prod/pipeline.py sync --model "${WHISPER_MODEL:-small}"
node prod/render.mjs
"$PYTHON" prod/pipeline.py mix
"$PYTHON" prod/pipeline.py srt
"$PYTHON" prod/pipeline.py qa --model "${WHISPER_MODEL:-small}"
"$PYTHON" prod/pipeline.py publish
