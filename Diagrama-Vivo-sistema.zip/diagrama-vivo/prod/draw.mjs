import {GlobalFonts} from '@napi-rs/canvas';
import {fileURLToPath} from 'node:url';
import {ease} from './timeline.mjs';
export const P={bg:'#16181c',bg2:'#1d2026',ink:'#e8ebee',gray:'#aeb6bf',mid:'#767e88',line:'#3a4048',dark:'#262a30',steel:'#c9cfd6',steel2:'#8d959f',amber:'#ffb020',light:'#ffd25e',shade:'#e08a00',danger:'#ff5347'};
for(const [file,family] of [['anton/files/anton-latin-400-normal.woff2','Anton'],['barlow-condensed/files/barlow-condensed-latin-500-normal.woff2','Barlow Condensed'],['montserrat/files/montserrat-latin-900-normal.woff2','Montserrat']]){
 const ok=GlobalFonts.registerFromPath(fileURLToPath(new URL('../node_modules/@fontsource/'+file,import.meta.url)),family);if(!ok)throw Error('Fuente ausente: '+family);
}
export function line(c,points,color=P.steel,width=4){c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle=color;c.lineWidth=width;c.lineJoin='round';c.lineCap='round';c.stroke();}
export function circle(c,x,y,r,fill,stroke=P.steel,width=4){c.beginPath();c.arc(x,y,r,0,Math.PI*2);if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke()}}
export function pin(c,x,y,r=13){circle(c,x,y,r,P.dark,P.steel2,3);line(c,[[x-r*.4,y],[x+r*.4,y]],P.mid,2)}
export function gear(c,x,y,r,angle,teeth=24){c.save();c.translate(x,y);c.rotate(angle);c.beginPath();for(let i=0;i<teeth;i++)for(let j=0;j<4;j++){const a=(i+j/4)*Math.PI*2/teeth,rr=j===1||j===2?r:r-19;const px=Math.cos(a)*rr,py=Math.sin(a)*rr;i||j?c.lineTo(px,py):c.moveTo(px,py)}c.closePath();c.fillStyle=P.dark;c.fill();c.strokeStyle=P.steel;c.lineWidth=4;c.stroke();c.restore()}
export function spiral(c,x,y,rotation){const points=[];for(let i=0;i<=340;i++){let a=i/340*8*Math.PI+rotation,r=18+i/340*120;points.push([x+Math.cos(a)*r,y+Math.sin(a)*r])}line(c,points,P.mid,4)}
export function belt(c,x,y,length,offset){c.fillStyle=P.dark;c.fillRect(x,y,100,length);line(c,[[x,y],[x,y+length]],P.steel2,4);line(c,[[x+100,y],[x+100,y+length]],P.steel2,4);c.save();c.beginPath();c.rect(x,y,100,length);c.clip();for(let k=-100;k<length+100;k+=22)line(c,[[x+8,y+k+offset%22],[x+92,y+k-25+offset%22]],P.line,2);c.restore()}
export function person(c,x,y,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);circle(c,0,0,16,null,P.mid,3);line(c,[[0,16],[0,80],[-25,120]],P.mid,3);line(c,[[0,80],[25,120]],P.mid,3);line(c,[[-30,55],[0,30],[30,55]],P.mid,3);c.restore()}
export function label(c,text,x,y,target){c.font='28px Anton';c.fillStyle=P.ink;c.textAlign='left';const w=c.measureText(text).width,m=c.getTransform();x=Math.min(Math.max(x,(55-m.e)/m.a),(905-m.e)/m.a-w);y=Math.min(Math.max(y,(125-m.f)/m.d),(1530-m.f)/m.d);c.fillText(text,x,y);if(target){line(c,[[x+w/2,y+12],[x+w/2,y+28],target],P.mid,2);circle(c,...target,4,P.steel,null)}}
export function mechanism(c,pose,angle){
 // Cutaway structural frame with mounting holes and section hatching.
 c.strokeStyle=P.line;c.lineWidth=5;c.beginPath();c.roundRect(155,310,635,1115,40);c.stroke();
 for(let y=360;y<1380;y+=26){line(c,[[155,y],[174,y-19]],P.line,2);line(c,[[770,y],[789,y-19]],P.line,2)}
 for(const [x,y] of [[192,350],[752,350],[192,1385],[752,1385]])pin(c,x,y,12);
 belt(c,325,190,510,angle*90);
 // Reel and concentric ratchet, same geometry through every shot.
 gear(c,450,700,235,angle,24);circle(c,450,700,204,P.bg2,P.mid,3);
 spiral(c,450,700,angle*.3);
 for(let i=0;i<6;i++){const a=angle+i*Math.PI/3;pin(c,450+Math.cos(a)*171,700+Math.sin(a)*171,9)}
 circle(c,450,700,53,P.dark,P.steel,5);circle(c,450,700,24,P.steel2,P.ink,3);
 line(c,[[450,659],[450,741]],P.dark,5);line(c,[[409,700],[491,700]],P.dark,5);
 // Ball cup, cam lever, push rod and pawl share contact points.
 const bx=592+pose.ball*67, cupY=x=>1305-.012*(x-610)**2,by=cupY(bx)-30;
 // Tangent cam contact: the ball stays seated and pushes the lever, never floats.
 const leverEnd=1247+(by-30-1247)/(bx-590)*(738-590);
 c.beginPath();for(let x=535;x<=710;x+=5){x===535?c.moveTo(x,cupY(x)):c.lineTo(x,cupY(x))}for(let x=710;x>=535;x-=5)c.lineTo(x,cupY(x)+35);c.closePath();c.fillStyle=P.dark;c.fill();c.strokeStyle=P.steel2;c.lineWidth=5;c.stroke();
 line(c,[[485,1225],[590,1247],[738,leverEnd]],P.steel,14);pin(c,485,1225,17);
 line(c,[[738,leverEnd],[738,1040]],P.steel2,12);
 c.save();c.translate(738,1010);c.rotate(pose.pawl*.4);c.beginPath();c.moveTo(18,35);c.lineTo(-8,-22);c.lineTo(-185,-60);c.lineTo(-193,-34);c.lineTo(-49,-4);c.lineTo(-12,47);c.closePath();c.fillStyle=P.steel2;c.fill();c.strokeStyle=P.steel;c.lineWidth=3;c.stroke();c.restore();pin(c,738,1010,18);
 c.save();c.shadowColor=P.amber;c.shadowBlur=30;const g=c.createRadialGradient(bx-9,by-12,2,bx,by,30);g.addColorStop(0,P.light);g.addColorStop(.6,P.amber);g.addColorStop(1,P.shade);circle(c,bx,by,30,g,P.light,2);c.restore();
 label(c,'CARRETE',205,1015,[360,900]);label(c,'GARRA',590,1100,[670,980]);label(c,'BOLITA',340,1370,[bx,by]);label(c,'PALANCA',215,1168,[490,1225]);
}
export function draw(c,t,state,timeline,captions=false){
 const bg=c.createLinearGradient(0,0,1080,1920);bg.addColorStop(0,P.bg);bg.addColorStop(1,P.bg2);c.fillStyle=bg;c.fillRect(0,0,1080,1920);
 for(let x=0;x<1080;x+=48)line(c,[[x,0],[x,1920]],'rgba(255,255,255,0.045)',1);
 for(let y=0;y<1920;y+=48)line(c,[[0,y],[1080,y]],'rgba(255,255,255,0.045)',1);
 c.save();c.beginPath();c.rect(40,90,880,1480);c.clip();
 const cam=state.camera;const micro=Math.sin(2*Math.PI*t/timeline.duration)*1.6;
 c.translate(480+micro,840);c.scale(cam.zoom,cam.zoom);c.translate(-cam.x,-cam.y);
 // Integral-like spool displacement is continuous and frozen after the locking word.
 const lock=timeline.beats.find(b=>b.id==='lock')?.start??timeline.duration;
 let angle=Math.min(t,lock)*.57 + .08;
 if(t>=timeline.loop.end)angle+=(.08-angle)*ease((t-timeline.loop.end)/(timeline.duration-timeline.loop.end-1/30));
 mechanism(c,state.pose,angle);c.restore();
 if(captions){let i=timeline.words.findIndex(w=>t>=w.start&&t<w.end);if(i>=0){const group=Math.floor(i/3)*3,words=timeline.words.slice(group,group+3);c.font='900 47px Montserrat';const widths=words.map(w=>c.measureText(w.text).width+17),total=widths.reduce((a,b)=>a+b,0);let x=480-total/2;words.forEach((w,j)=>{c.save();c.translate(x+widths[j]/2,1600);if(group+j===i){const pop=1+.08*Math.sin(Math.PI*Math.min(1,(t-w.start)/Math.max(.04,w.end-w.start)));c.scale(pop,pop)}c.textAlign='center';c.strokeStyle=P.bg;c.lineWidth=9;c.strokeText(w.text,0,0);c.fillStyle=group+j===i?P.ink:P.gray;c.fillText(w.text,0,0);c.restore();x+=widths[j]})}}
}
