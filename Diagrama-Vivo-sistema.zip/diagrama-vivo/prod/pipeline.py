#!/usr/bin/env python3
"""Diagrama Vivo CLI. Run from project root. Production gates fail closed."""
import argparse, difflib, hashlib, json, math, os, re, subprocess, sys, unicodedata, urllib.request, wave
from pathlib import Path


def save(path, data):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def run(args, capture=True):
    p=subprocess.run([str(x) for x in args],capture_output=capture,text=True)
    if p.returncode:
        raise RuntimeError(f'{args[0]} falló ({p.returncode}): {(p.stderr or "")[-2500:]}')
    return p.stdout or ''


def tokens(text):
    text=''.join(c for c in unicodedata.normalize('NFD',text.lower()) if unicodedata.category(c)!='Mn')
    return re.findall(r'\w+',text,flags=re.UNICODE)


def narration():
    lines=Path('guion.txt').read_text(encoding='utf-8').splitlines()
    if not lines or not lines[0].startswith('PIEZA ÁMBAR: '):
        raise ValueError('La primera línea debe declarar PIEZA ÁMBAR: ...')
    return '\n'.join(lines[1:]).strip()


def compare(expected, actual):
    a,b=tokens(expected),tokens(actual)
    if not a: raise ValueError('Guion vacío')
    # Levenshtein word error rate: substitutions, insertions AND deletions.
    prev=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,prev[j]+1,prev[j-1]+(x!=y)))
        prev=row
    wer=prev[-1]/len(a)
    return {'agreement':max(0,1-wer),'wer':wer,'expected_words':len(a),'actual_words':len(b),
            'diff':'\n'.join(difflib.unified_diff(a,b,fromfile='guion',tofile='transcripcion',lineterm=''))}


def transcribe(audio, out, model):
    from faster_whisper import WhisperModel
    engine=WhisperModel(model,device='cpu',compute_type='int8',cpu_threads=min(os.cpu_count() or 4,8))
    # No initial_prompt: don't bias QA toward the expected script.
    segments, info=engine.transcribe(str(audio),language='es',beam_size=5,word_timestamps=True,vad_filter=False,condition_on_previous_text=False)
    words=[]; text=[]
    for s in segments:
        text.append(s.text.strip())
        for w in s.words or []:
            words.append({'text':w.word.strip(),'start':round(w.start,4),'end':round(w.end,4),'probability':w.probability})
    if not words:raise ValueError('Whisper no detectó palabras')
    previous=-1
    for w in words:
        if w['start']<previous or w['end']<=w['start']:raise ValueError('Alineación inválida; revisar audio y transcripción')
        previous=w['end']
    joined=' '.join(text); check=compare(narration(),joined)
    data={'source':'faster-whisper','model':model,'language':info.language,'audio_sha256':sha(audio),'words':words,'quality':check}
    save(out,data);Path(out).with_suffix('.txt').write_text(joined+'\n',encoding='utf-8')
    if str(out)=='words.json':Path('transcript.txt').write_text(joined+'\n',encoding='utf-8')
    Path(out).with_suffix('.diff.txt').write_text(check['diff'] or 'Sin diferencias\n',encoding='utf-8')
    if check['agreement']<.98:raise ValueError(f'Coincidencia {check["agreement"]:.1%} <98%; ver {out} y diff. No continuar.')
    return data


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def probe(p):return json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',p]))


def loudness(p):
    if not any(s['codec_type']=='audio' for s in probe(p)['streams']):raise ValueError('Archivo sin pista de audio; no se pueden medir LUFS')
    r=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vn','-af','loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True)
    if r.returncode:raise ValueError(r.stderr[-1000:])
    match=re.findall(r'\{\s*"input_i".*?\}',r.stderr,re.S)
    if not match:raise ValueError('Sin medición LUFS')
    return json.loads(match[-1])


def tts(args):
    # REST mode for machines with a configured key; manual voz.wav is equally supported.
    key=os.environ.get('ELEVENLABS_API_KEY')
    if not key:raise ValueError('Configurar ELEVENLABS_API_KEY en el entorno o aportar voz.wav. No guardar claves en el proyecto.')
    cfg=json.loads(Path('voice.json').read_text())
    body=json.dumps({'text':narration(),'model_id':cfg['model_id'],'voice_settings':cfg['voice_settings']}).encode()
    req=urllib.request.Request('https://api.elevenlabs.io/v1/text-to-speech/'+cfg['voice_id']+'?output_format=mp3_44100_128',data=body,headers={'xi-api-key':key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=120) as response:Path('voz-original.mp3').write_bytes(response.read())
    run(['ffmpeg','-y','-v','error','-i','voz-original.mp3','-ar','48000','-ac','1','voz.wav'])
    save('qa/voice-origin.json',{'provider':'ElevenLabs','config':cfg,'sha256':sha('voz.wav')})


def sfx(timeline):
    import numpy as np
    sr=48000;n=math.ceil(timeline['duration']*sr);sound=np.zeros(n,dtype=np.float64)
    rng=np.random.default_rng(17)
    for beat in timeline['beats']:
        kind=beat.get('sfx')
        if not kind:continue
        duration={'click':.09,'lever':.16,'roll':.32}[kind]
        t=np.arange(int(duration*sr))/sr
        if kind=='click':signal=(np.sin(2*np.pi*1700*t)+rng.normal(0,.3,len(t)))*np.exp(-t*70)*.045
        elif kind=='lever':signal=np.sin(2*np.pi*(500*t+800*t*t))*np.exp(-t*25)*.025
        else:signal=rng.normal(0,1,len(t))*np.sin(np.pi*t/duration)**2*.012
        start=round(beat['start']*sr);end=min(n,start+len(t));sound[start:end]+=signal[:end-start]
    with wave.open('efectos.wav','wb') as f:
        f.setparams((1,2,sr,0,'NONE','not compressed'));f.writeframes((np.clip(sound,-1,1)*32767).astype('<i2').tobytes())


def mix(args):
    words=json.loads(Path('words.json').read_text())
    if words.get('source')!='faster-whisper' or words['quality']['agreement']<.98:raise ValueError('No hay alineación válida')
    if words['audio_sha256']!=sha('voz.wav'):raise ValueError('La voz cambió: repetir sync y render')
    timeline=json.loads(Path('qa/timeline.json').read_text())
    if timeline['words']!=words['words']:raise ValueError('Timeline obsoleto: repetir render')
    duration=timeline['duration'];voice_duration=float(probe('voz.wav')['format']['duration'])
    if voice_duration>duration:raise ValueError('La voz excede la duración; ampliar duración en escenas. No recortar ni acelerar voz.')
    sfx(timeline)
    # Normalize voice first so effects remain at least 18 dB below calibrated narration.
    run(['ffmpeg','-y','-v','error','-i','voz.wav','-af','loudnorm=I=-16:TP=-3:LRA=11','-ar','48000','qa/voz-mezcla.wav'])
    graph=f'[0:a]apad,atrim=duration={duration},asplit=2[v][sc];[1:a][sc]sidechaincompress=threshold=0.025:ratio=10:attack=5:release=150[fx];[v][fx]amix=inputs=2:normalize=0:duration=first[out]'
    run(['ffmpeg','-y','-v','error','-i','qa/voz-mezcla.wav','-i','efectos.wav','-filter_complex',graph,'-map','[out]','-ar','48000','qa/premezcla.wav'])
    measured=loudness('qa/premezcla.wav');save('qa/mezcla-pass1.json',measured)
    settings=f'loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={measured["input_i"]}:measured_TP={measured["input_tp"]}:measured_LRA={measured["input_lra"]}:measured_thresh={measured["input_thresh"]}:offset={measured["target_offset"]}:linear=true'
    run(['ffmpeg','-y','-v','error','-i','imagen.mp4','-i','qa/premezcla.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-af',settings,'-ar','48000','-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart','salida.mp4'])
    save('qa/mix-origin.json',{'voice_sha256':sha('voz.wav'),'words_sha256':sha('words.json'),'output_sha256':sha('salida.mp4')})


def contact(video):
    from PIL import Image, ImageDraw
    directory=Path('qa/contacto');directory.mkdir(parents=True,exist_ok=True)
    for p in directory.glob('*.jpg'):p.unlink()
    run(['ffmpeg','-y','-v','error','-i',video,'-vf','fps=2,scale=216:384',str(directory/'%04d.jpg')])
    files=sorted(directory.glob('*.jpg'))
    if not files:raise ValueError('Hoja vacía')
    # Paginate for long videos; every frame is included, not just the first page.
    for page,start in enumerate(range(0,len(files),25),1):
        part=files[start:start+25];sheet=Image.new('RGB',(5*216,math.ceil(len(part)/5)*412),'#16181c');d=ImageDraw.Draw(sheet)
        for i,p in enumerate(part):
            x=i%5*216;y=i//5*412;sheet.paste(Image.open(p),(x,y));d.text((x+8,y+387),f'{(start+i)/2:.1f} s',fill='white')
        sheet.save(f'qa/contacto-{page:02d}.jpg',quality=92)
    return len(files)


def srt(words,out='subtitulos.srt'):
    def stamp(t):
        n=round(t*1000);return f'{n//3600000:02d}:{n//60000%60:02d}:{n//1000%60:02d},{n%1000:03d}'
    Path(out).write_text('\n\n'.join(f'{i+1}\n{stamp(w["start"])} --> {stamp(w["end"])}\n{w["text"]}' for i,w in enumerate(words))+'\n',encoding='utf-8')


def qa(args):
    video=Path(args.video);report={'file':str(video),'sha256':sha(video),'status':'NO APROBADO','checks':{},'failures':[]}
    def check(name,fn):
        try:report['checks'][name]=fn()
        except Exception as e:report['failures'].append(f'{name}: {e}')
    def technical():
        p=probe(video);save('qa/ffprobe.json',p)
        v=next(s for s in p['streams'] if s['codec_type']=='video');a=[s for s in p['streams'] if s['codec_type']=='audio']
        if (v['width'],v['height'],v['r_frame_rate'])!=(1080,1920,'30/1'):raise ValueError('Formato incorrecto')
        expected=json.loads(Path('qa/timeline.json').read_text())['duration']
        if abs(float(p['format']['duration'])-expected)>.08:raise ValueError('Duración inesperada')
        run(['ffmpeg','-v','error','-xerror','-i',video,'-f','null','-'])
        return {'width':1080,'height':1920,'fps':30,'duration':p['format']['duration'],'has_audio':bool(a),'full_decode':True}
    check('technical',technical);check('contact_sheet_frames',lambda:contact(str(video)))
    def audio():
        m=loudness(video);save('qa/lufs.json',m)
        if abs(float(m['input_i'])+14)>.5 or float(m['input_tp'])>-1:raise ValueError(f'Fuera de objetivo: {m}')
        return m
    check('loudness',audio)
    def final_transcript():
        # Decode delivered MP4, never reuse voz.wav as the final transcription source.
        if not any(s['codec_type']=='audio' for s in probe(video)['streams']):raise ValueError('MP4 sin voz: no hay audio que transcribir')
        run(['ffmpeg','-y','-v','error','-i',video,'-vn','-ar','16000','-ac','1','qa/audio-final.wav'])
        data=transcribe('qa/audio-final.wav','qa/words-final.json',args.model);srt(data['words'],'qa/subtitulos-final.srt');return data['quality']
    check('final_transcription',final_transcript)
    def provenance():
        origin=json.loads(Path('qa/mix-origin.json').read_text())
        if origin['output_sha256']!=sha(video) or origin['voice_sha256']!=sha('voz.wav'):raise ValueError('Archivo o voz cambiados')
        return origin
    check('voice_provenance',provenance)
    def review():
        r=json.loads(Path('qa/revision-visual.json').read_text())
        if r['video_sha256']!=sha(video) or not r.get('all_pages_reviewed') or not r.get('word_action_sync_checked') or r.get('defects') or not r.get('reviewer'):raise ValueError('Revisión incompleta o defectos abiertos')
        return r
    check('visual_review',review)
    if not report['failures']:report['status']='APROBADO'
    save('qa/informe.json',report)
    Path('qa/informe.md').write_text('# QA Diagrama Vivo\n\nEstado: **'+report['status']+'**\n\nSHA-256: `'+report['sha256']+'`\n\n'+'\n'.join('- '+f for f in report['failures'])+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if report['failures']:raise SystemExit(2)


def script_check(args):
    text=narration();n=len(tokens(text));demo=args.demo
    cfg=json.loads(Path('escenas/bolita.json').read_text())
    declared=Path('guion.txt').read_text(encoding='utf-8').splitlines()[0].split(':',1)[1].strip()
    if declared!=cfg['decisivePiece']:raise ValueError('La pieza del guion difiere de la pieza de escenas')
    if not demo and not 110<=n<=160:raise ValueError(f'{n} palabras: se requieren 110–160')
    if not demo:
        cfg=json.loads(Path('escenas/bolita.json').read_text())
        if not 45<=cfg.get('duration',0)<=90:raise ValueError('Configurar duration entre 45 y 90 segundos para producción')
    print(json.dumps({'words':n,'seconds_at_150_165_wpm':[round(n/165*60,1),round(n/150*60,1)],'mode':'demo' if demo else 'production'},ensure_ascii=False))


def publish(args):
    cfg=json.loads(Path('publicacion.json').read_text())
    if not 3<=len(cfg['hashtags'])<=5:raise ValueError('Usar 3–5 hashtags')
    Path('kit-publicacion.md').write_text(f'# {cfg["title"]}\n\n{cfg["hook"]}\n\n{cfg["description"]}\n\n{cfg["question"]}\n\n'+ ' '.join(cfg['hashtags'])+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('script');p.add_argument('--demo',action='store_true');p.set_defaults(fn=script_check)
    p=sub.add_parser('tts');p.set_defaults(fn=tts)
    p=sub.add_parser('sync');p.add_argument('--model',default='small');p.add_argument('--audio',default='voz.wav');p.add_argument('--out',default='words.json');p.set_defaults(fn=lambda a:transcribe(a.audio,a.out,a.model))
    p=sub.add_parser('mix');p.set_defaults(fn=mix)
    p=sub.add_parser('qa');p.add_argument('--video',default='salida.mp4');p.add_argument('--model',default='small');p.set_defaults(fn=qa)
    p=sub.add_parser('srt');p.set_defaults(fn=lambda a:srt(json.loads(Path('words.json').read_text())['words']))
    p=sub.add_parser('publish');p.set_defaults(fn=publish)
    args=parser.parse_args()
    try:args.fn(args)
    except Exception as e:print('DETENIDO: '+str(e),file=sys.stderr);sys.exit(1)
if __name__=='__main__':main()
