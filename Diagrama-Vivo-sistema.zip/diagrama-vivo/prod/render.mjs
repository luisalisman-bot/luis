import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createCanvas} from '@napi-rs/canvas';
import {compile,stateAt} from './timeline.mjs';
import {draw} from './draw.mjs';
const args=process.argv.slice(2), preview=args.includes('--fixture-preview'), captions=args.includes('--captions');
const words=JSON.parse(fs.readFileSync(preview?'tests/words.fixture.json':'words.json'));
if(!preview && words.source!=='faster-whisper')throw Error('La producción requiere palabras de faster-whisper');
const config=JSON.parse(fs.readFileSync('escenas/bolita.json'));
if(config.mechanism!=='seatbelt-ball-sensor' || config.decisivePiece!=='BOLITA')throw Error('Este renderer implementa el sensor de bola; añadir geometría para otro mecanismo');
if(!preview && (!words.quality || words.quality.agreement<.98))throw Error('Coincidencia de transcripción inferior al 98%');
const timeline=compile(words,config);
fs.mkdirSync('qa',{recursive:true});fs.mkdirSync('frames',{recursive:true});
fs.writeFileSync('qa/timeline.json',JSON.stringify(timeline,null,2));
const canvas=createCanvas(1080,1920),ctx=canvas.getContext('2d');
const n=Math.ceil(timeline.duration*30);
// Remove old frames so a shorter re-render cannot encode stale trailing frames.
for(const f of fs.readdirSync('frames'))if(/^\d{6}\.png$/.test(f))fs.unlinkSync(path.join('frames',f));
for(let i=0;i<n;i++){const t=i/30;draw(ctx,t,stateAt(t,timeline),timeline,captions||config.captions);fs.writeFileSync(`frames/${String(i).padStart(6,'0')}.png`,canvas.toBuffer('image/png'));if(i%60===0)console.log(`Render ${i}/${n}`)}
const out=preview?'preview-mudo.mp4':'imagen.mp4';
const p=spawnSync('ffmpeg',['-y','-v','error','-framerate','30','-i','frames/%06d.png','-frames:v',String(n),'-c:v','libx264','-crf','18','-preset','fast','-pix_fmt','yuv420p','-movflags','+faststart',out],{stdio:'inherit'});
if(p.status!==0)process.exit(p.status||1);
fs.writeFileSync('qa/render.json',JSON.stringify({output:out,frames:n,source:words.source,captions:captions||config.captions},null,2));
console.log(out);
