export const normalize = s => s.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().match(/[\p{L}\p{N}]+/gu)?.join(' ') || '';
export function validateWords(data) {
  if(!Array.isArray(data.words) || !data.words.length) throw Error('words.json vacío');
  let previous=-1;
  for(const w of data.words) {
    if(!normalize(w.text)||!Number.isFinite(w.start)||!Number.isFinite(w.end)||w.start<previous||w.start<0||w.end<=w.start) throw Error('Tiempos inválidos: '+JSON.stringify(w));
    previous=w.end;
  }
}
export function anchor(words, spec) {
  const tokens=normalize(spec.phrase).split(' '), hits=[];
  for(let i=0;i<=words.length-tokens.length;i++) {
    if(tokens.every((v,j)=>normalize(words[i+j].text)===v)) hits.push({start:words[i].start,end:words[i+tokens.length-1].end,index:i});
  }
  if(!hits.length) throw Error('Ancla ausente: '+spec.phrase);
  if(hits.length>1 && !spec.occurrence) throw Error('Ancla ambigua; indica occurrence (1..N): '+spec.phrase);
  const result=hits[(spec.occurrence||1)-1];
  if(!result) throw Error('Occurrence fuera de rango: '+spec.phrase);
  return result;
}
export function compile(data, config) {
  validateWords(data);
  const beats=config.beats.map(b=>({...b,...anchor(data.words,b.anchor)}));
  for(let i=1;i<beats.length;i++) if(beats[i].start<=beats[i-1].start) throw Error('Escenas fuera de orden');
  if(beats[0].start>0.5) throw Error('El hook empieza tarde');
  const loop=anchor(data.words,config.loop.anchor);
  const duration=config.duration || Math.ceil(data.words.at(-1).end*30+12)/30;
  if(duration < data.words.at(-1).end) throw Error('La duración cortaría la voz');
  if(loop.end>=duration) throw Error('Falta cola para el bucle; ampliar duración');
  return {beats,loop,duration,words:data.words,source:data.source};
}
export const ease=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
const blend=(a,b,p)=>p>=1?{...b}:p<=0?{...a}:Object.fromEntries(Object.keys(b).map(k=>[k,a[k]+(b[k]-a[k])*p]));
export function stateAt(t, timeline) {
  const {beats,loop,duration}=timeline;
  let pose=beats[0].pose,camera=beats[0].camera;
  for(let i=1;i<beats.length;i++) {
    const b=beats[i]; if(t<b.start)break;
    const next=beats[i+1]?.start ?? loop.start;
    const span=Math.max(1/30,Math.min(b.end-b.start,next-b.start));
    const p=ease((t-b.start)/span);
    pose=blend(pose,b.pose,p);camera=blend(camera,b.camera,p);
  }
  // Reset only after the closing word finishes. No fixed scene timestamps.
  if(t>=loop.end){const p=ease((t-loop.end)/(duration-loop.end-1/30));pose=blend(pose,beats[0].pose,p);camera=blend(camera,beats[0].camera,p);}
  return {pose,camera};
}
