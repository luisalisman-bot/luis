# QA Diagrama Vivo

Estado: **NO APROBADO**

SHA-256: `7a76de54d60786176b243b9cc4b295968783bf570bc8df4918ba313634cabe3e`

- loudness: Archivo sin pista de audio; no se pueden medir LUFS
- final_transcription: MP4 sin voz: no hay audio que transcribir
- voice_provenance: [Errno 2] No such file or directory: 'qa/mix-origin.json'
- visual_review: [Errno 2] No such file or directory: 'qa/revision-visual.json'
