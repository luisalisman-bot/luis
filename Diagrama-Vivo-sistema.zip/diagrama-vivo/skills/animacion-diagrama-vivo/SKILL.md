---
name: animacion-diagrama-vivo
description: Dibujar cortes mecánicos paramétricos con escenas activadas por palabras.
---

# animacion-diagrama-vivo

Rutas relativas a la raíz de Diagrama Vivo.

1. Librería `prod/draw.mjs`; motor puro `prod/timeline.mjs`; render `prod/render.mjs`. Stack Node + @napi-rs/canvas, PNG, FFmpeg H.264 yuv420p.
2. Paleta: fondo #16181c→#1d2026, rejilla rgba(255,255,255,0.045); tinta #e8ebee; grises #aeb6bf #767e88 #3a4048 #262a30; acero #c9cfd6 #8d959f; solo la pieza decisiva #ffb020 con luz #ffd25e, sombra #e08a00 y glow; fallo puntual #ff5347.
3. Primitivas exportadas: pin, gear, spiral, belt, person, circle, line, label, mechanism. Misma geometría en todo el vídeo. Dibujo abierto en corte. Anton para etiquetas de pieza; Barlow Condensed 500 para notas técnicas; Montserrat 900 para subtítulos.
4. Escenas: `escenas/bolita.json`. Cada beat usa anchor.phrase, occurrence opcional 1-based si se repite; pose y camera. No introducir timestamps de escena. Ancla ausente/ambigua, orden inválido o audio que excede duración detienen render.
5. Ejecutar `node prod/render.mjs` tras sync. Para subtítulos: `node prod/render.mjs --captions` o captions=true en JSON. Solo etiquetas breves dentro del mecanismo. Palabra activa con pop y mayor luminosidad, sin aplicar ámbar al texto.
6. 1080×1920, 30 fps. Acción recortada al rectángulo seguro x40–920, y90–1570. Subtítulos hasta y1640, fondo libre en los últimos 250 px. Zoom/paneo smoothstep hacia la acción, micro movimiento periódico; hook ya móvil.
7. Para otro mecanismo: añadir renderer con geometría propia y configuración de beats; reutilizar cámara, anclas, primitivas y audio. No es generación automática de mecanismos arbitrarios.
8. `node prod/render.mjs --fixture-preview` genera una prueba muda de 10 s solo para inspección gráfica; no aprueba sincronía de narración.
