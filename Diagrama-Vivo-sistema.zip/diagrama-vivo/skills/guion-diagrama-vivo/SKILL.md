---
name: guion-diagrama-vivo
description: Escribir guiones TikTok en español para un mecanismo y una pieza decisiva.
---

# guion-diagrama-vivo

Rutas relativas a la raíz de Diagrama Vivo.

1. Crear `guion.txt`. Primera línea obligatoria: `PIEZA ÁMBAR: BOLITA` (o la pieza elegida); no se narra esta línea.
2. Texto de 110–160 palabras a 150–165 ppm; duración calculada con voz real, objetivo 60–75 s, límites 45–90 s. Con 110 palabras a 165 ppm salen 40 s: ampliar texto, nunca ralentizar audio automáticamente.
3. Hook de 0–2 s: nombrar pieza y decisión; primer frame en acción. Problema en una frase. Tres a cinco acciones físicamente visibles. Dato sorprendente verificable con fuente. Cierre que conecta con hook y pregunta corta.
4. Comando: `.venv/bin/python prod/pipeline.py script`. Para la prueba corta: añadir `--demo`. El guion de demostración no necesita la estructura de un vídeo completo.
5. Banco: bola del sensor inercial / bloqueo; trinquete de llave / retención; pasador de fusible mecánico / liberación; válvula de olla / presión. Elegir una sola pieza; verificar el diseño concreto antes de afirmar cifras.
6. Revisar guion antes de generar voz; no producir un primer vídeo completo hasta recibir el tema solicitado.
