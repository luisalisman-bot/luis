---
name: kit-publicacion-tiktok
description: Preparar título, descripción y hashtags para el mecanismo del guion.
---

# kit-publicacion-tiktok

Rutas relativas a la raíz de Diagrama Vivo.

1. Leer `guion.txt` y `escenas/bolita.json`. Redactar `publicacion.json`: title, hook, description, question, hashtags.
2. Primera línea con gancho de la pieza, pregunta breve para comentarios, 3–5 hashtags de ingeniería y mecanismo. No prometer alcance viral ni inventar cifras.
3. `.venv/bin/python prod/pipeline.py publish` produce `kit-publicacion.md`; revisión editorial para cada nuevo tema.
4. Copia preparada no equivale a vídeo aprobado. Publicar en TikTok solo por instrucción expresa, con QA completa. Este sistema no publica automáticamente.
