---
name: mezcla-voz-efectos
description: Mezclar voz preservada y efectos discretos con ducking y loudness medido.
---

# mezcla-voz-efectos

Rutas relativas a la raíz de Diagrama Vivo.

1. Requiere `voz.wav`, `words.json`, `imagen.mp4` y `qa/timeline.json`. Ejecutar `.venv/bin/python prod/pipeline.py mix`.
2. `prod/pipeline.py` comprueba hash de voz y timeline antes de mezclar. Efectos originales sintetizados reproducibles: roll, lever, click; eventos anclados al inicio de palabra. Sin música.
3. Voz calibrada en copia de mezcla a −16 LUFS, efectos con picos conservadores; sidechaincompress threshold=0.025 ratio=10 attack=5 release=150. Original no se corta, acelera ni reescribe; apad solo añade silencio al final.
4. Amix sin normalización automática. loudnorm en dos pasadas con I=-14 TP=-1.5 LRA=11, usando valores medidos, AAC 192 kb/s, 48 kHz. Margen de pico para el códec.
5. `qa/premezcla.wav`, `qa/mezcla-pass1.json`, `efectos.wav`, `salida.mp4`. Medición sobre MP4 final en QA: tolerancia ±0.5 LUFS y pico verdadero ≤−1 dBTP. Si falla, ajustar mezcla, repetir exportación y QA. Escuchar efectos bajo voz: el volumen numérico no sustituye revisión auditiva.
