---
name: qa-video-final
description: Validar el MP4 entregable sin permitir aprobación con comprobaciones faltantes.
---

# qa-video-final

Rutas relativas a la raíz de Diagrama Vivo.

1. `.venv/bin/python prod/pipeline.py qa --video salida.mp4 --model small`. Código 2 = no aprobado. Leer `qa/informe.json` y `qa/informe.md`.
2. ffprobe: 1080×1920, 30 fps, duración dentro de 0.08 s. FFmpeg -xerror decodifica archivo completo.
3. Hoja completa a 2 fps, más exigente que 1 frame cada 2–3 s; `qa/contacto-XX.jpg` paginado sin omitir final. Revisar todas las páginas y momentos de acción a tamaño completo con voz.
4. Verificar encuadre lleno, zonas seguras, pieza ámbar única, geometría coherente, contacto físico, cámara viva, solo etiquetas cortas y subtítulos si se activan; comprobar acciones contra palabras de `qa/timeline.json`. Escuchar efectos bajo voz.
5. Transcribir audio decodificado DEL MP4 con Whisper small, sin reutilizar transcripción de voz. Coincidencia ≥98%, `qa/words-final.json` + diff. LUFS medido sobre MP4: −14±0.5; pico verdadero ≤−1.
6. Solo tras revisión real crear `qa/revision-visual.json`: {"video_sha256":"HASH_REAL", "reviewer":"nombre", "all_pages_reviewed":true, "word_action_sync_checked":true, "defects":[], "notes":"evidencia concreta"}. Obtener hash con `sha256sum salida.mp4`. Nunca rellenar revisión automáticamente ni aprobar solo porque el render terminó.
7. Reejecutar QA. Cualquier cambio de archivo invalida el hash y requiere revisión. No llamar final a una preview ni a una prueba sin voz/modelo. Para defectos: registrar momento, evidencia, arreglo, re-render y revisión.
