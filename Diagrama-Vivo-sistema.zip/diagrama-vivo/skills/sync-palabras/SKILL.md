---
name: sync-palabras
description: Alinear voz real con faster-whisper y detenerse bajo 98% de coincidencia.
---

# sync-palabras

Rutas relativas a la raíz de Diagrama Vivo.

1. Trabajar desde la raíz del proyecto. Conservar `voz.wav` intacta. Para generar: `.venv/bin/python prod/pipeline.py tts`, usando `voice.json` y ELEVENLABS_API_KEY del entorno; alternativa: audio manual a `voz.wav`.
2. Ejecutar `.venv/bin/python prod/pipeline.py sync --model small`. Modelo local: `--model /ruta/al/modelo-ctranslate2`.
3. Implementación en `prod/pipeline.py`: faster-whisper CPU int8, idioma es, beam 5, word_timestamps=True, sin prompt que fuerce la transcripción.
4. Produce `words.json`, `words.txt`, `words.diff.txt`; copiar `words.txt` a `transcript.txt`. Incluye hash de voz, probabilidades, modelo y WER por distancia de edición de palabras (inserciones, omisiones y sustituciones). Normaliza tildes y puntuación.
5. Coincidencia = 1 − WER, debe ser ≥0.98. Código de salida distinto de cero detiene el pipeline. Revisar diff; corregir voz o errores reales de reconocimiento con evidencia y volver a transcribir. Nunca rebajar el umbral ni inventar marcas.
6. Las fixtures en `tests/` son sintéticas y están prohibidas en producción.
