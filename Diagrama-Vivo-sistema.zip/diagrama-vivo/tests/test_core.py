import importlib.util, unittest
spec=importlib.util.spec_from_file_location('pipeline','prod/pipeline.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class QualityGate(unittest.TestCase):
 def test_dropped_word_is_failure(self):self.assertLess(p.compare('la bolita levanta la palanca','la bolita la palanca')['agreement'],.98)
 def test_inserted_word_is_failure(self):self.assertLess(p.compare('la bolita sube','la bolita nunca sube')['agreement'],.98)
 def test_punctuation_not_spoken(self):self.assertEqual(p.compare('¡Frenó, subió!','freno subio')['agreement'],1)
 def test_empty_recognition_rejected(self):self.assertEqual(p.compare('la bolita sube','')['agreement'],0)
 def test_repetition_counts(self):self.assertLess(p.compare('sube la bola','sube sube la bola')['agreement'],.98)
if __name__=='__main__':unittest.main()
