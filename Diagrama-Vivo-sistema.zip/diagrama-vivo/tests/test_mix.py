"""Mixer integration with a synthetic tone and MOCKED ASR metadata. Not voice QA."""
import importlib.util, json, os, tempfile, unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('pipeline',str(Path('prod/pipeline.py').resolve()));p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class MixerIntegration(unittest.TestCase):
 def test_two_pass_encoded_loudness_and_voice_preserved(self):
  original=Path.cwd()
  with tempfile.TemporaryDirectory() as temp:
   try:
    os.chdir(temp);Path('qa').mkdir()
    p.run(['ffmpeg','-y','-v','error','-f','lavfi','-i','sine=frequency=240:sample_rate=48000:duration=10','voz.wav'])
    before=p.sha('voz.wav')
    p.run(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=black:s=160x240:r=30:d=10','-c:v','libx264','-pix_fmt','yuv420p','imagen.mp4'])
    # Explicit external dependency mock to isolate the mixer from unavailable ASR.
    p.save('words.json',{'source':'faster-whisper','model':'MOCK_FOR_MIX_TEST_ONLY','quality':{'agreement':1},'audio_sha256':before,'words':[{'text':'mock','start':0,'end':1}]})
    p.save('qa/timeline.json',{'duration':10,'words':[{'text':'mock','start':0,'end':1}],'beats':[{'start':2,'sfx':'click'},{'start':5,'sfx':'lever'},{'start':7,'sfx':'roll'}]})
    p.mix(None)
    measured=p.loudness('salida.mp4')
    self.assertLessEqual(abs(float(measured['input_i'])+14),.5)
    self.assertLessEqual(float(measured['input_tp']),-1)
    self.assertEqual(p.sha('voz.wav'),before)
    meta=json.loads(Path('qa/mix-origin.json').read_text());self.assertEqual(meta['voice_sha256'],before)
    with open('voz.wav','ab') as f:f.write(b'changed')
    with self.assertRaisesRegex(ValueError,'voz cambió'):p.mix(None)
   finally:os.chdir(original)
if __name__=='__main__':unittest.main()
