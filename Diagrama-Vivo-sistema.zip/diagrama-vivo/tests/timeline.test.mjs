import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {anchor,compile,stateAt,validateWords} from '../prod/timeline.mjs';
const data=JSON.parse(fs.readFileSync('tests/words.fixture.json')),cfg=JSON.parse(fs.readFileSync('escenas/bolita.json'));
test('missing phrase never falls back to guessed time',()=>assert.throws(()=>anchor(data.words,{phrase:'no existe'}),/ausente/));
test('repeated phrase requires explicit occurrence',()=>{const ws=[{text:'sube',start:0,end:.2},{text:'sube',start:.3,end:.5}];assert.throws(()=>anchor(ws,{phrase:'sube'}),/ambigua/);assert.equal(anchor(ws,{phrase:'sube',occurrence:2}).start,.3)});
test('changed voice automatically shifts all downstream events',()=>{const a=compile(data,cfg);const shifted={...data,words:data.words.map((w,i)=>({...w,start:w.start+(i>=10?.3:0),end:w.end+(i>=10?.3:0)}))};const b=compile(shifted,cfg);assert.equal(b.beats.at(-1).start,a.beats.at(-1).start+.3)});
test('voice cannot be cut',()=>assert.throws(()=>compile(data,{...cfg,duration:2}),/cortaría/));
test('invalid timestamps stop render',()=>assert.throws(()=>validateWords({words:[{text:'a',start:1,end:.5}]}),/inválidos/));
test('state is deterministic independent of render order',()=>{const a=compile(data,cfg);const first=stateAt(6.1,a);stateAt(9,a);assert.deepEqual(stateAt(6.1,a),first)});
test('loop returns pose and camera to opening frame',()=>{const a=compile(data,cfg);assert.deepEqual(stateAt(a.duration-1/30,a),stateAt(0,a))});
