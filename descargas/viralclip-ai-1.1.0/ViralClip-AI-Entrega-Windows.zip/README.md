# ViralClip AI local — versión 1.1.0

Base elegida: viralclip-ai-development-project.zip (sin “(1)”).

## Windows 10/11 x64

Ejecuta ViralClip-AI-Setup.exe, o extrae el ZIP y abre INSTALAR.cmd.
Se necesita Internet para instalar y descargar modelos la primera vez. El instalador
es un bootstrap: descarga Node.js verificado y dependencias, compila la app en el PC
y crea un acceso directo. NO es un paquete autónomo sin conexión.

Abre el acceso directo ViralClip AI. El estudio se abre en tu navegador, con un
servidor local limitado a 127.0.0.1 y un puerto libre. Mantén su consola abierta;
pulsa Intro en ella para detener el servidor. No pide permisos de administrador.

Datos: %LOCALAPPDATA%\ViralClipAI\data. Copia esta carpeta con la app cerrada
para hacer una copia de seguridad. La desinstalación conserva los proyectos.
No necesita instalar PostgreSQL ni configurar DATABASE_URL: usa PGlite persistente.

## Vídeos y YouTube

Importa un archivo propio, una ruta local o una URL autorizada. Para enlaces confirma
que tienes los derechos necesarios. Se instala yt-dlp desde su repositorio oficial,
comprobando SHA256. ACTUALIZAR_YOUTUBE.cmd permite actualizarlo si cambia YouTube.
No descarga vídeos privados a los que no tengas acceso ni elude DRM. Bloqueos,
restricciones regionales, autenticación, cambios de YouTube y cortes de Internet
pueden impedir la descarga. Importar el archivo original sigue siendo la alternativa.
No se han obtenido licencias de YouTube ni de titulares de vídeos por tu cuenta.

## Sin marca de agua añadida

Los ajustes nuevos dejan watermarkText vacío y logoPath sin configurar. La app no
impone su marca en el render. No elimina marcas que ya estén en el vídeo original.

## Primer análisis

Whisper local necesita descargar su modelo desde Hugging Face; el seguimiento de
personas también descarga un modelo. La instalación base usa CPU, sin CUDA. Puedes
usar una API propia en Configuración si lo prefieres. Los costes de API son tuyos.
Los modelos no están incluidos en el instalador. Se recomienda 8 GB RAM y varios GB
libres; vídeos grandes pueden requerir bastante más memoria y almacenamiento.

## Diagnóstico

Instalación: %LOCALAPPDATA%\ViralClipAI\instalacion.log.
Arranque: servidor.log y errores.log en esa misma carpeta.
Si se interrumpe la instalación, vuelve a ejecutar el instalador. Antes de reinstalar,
cierra la app. No desactives el antivirus ni SmartScreen. Este instalador no está
firmado y puede mostrar un aviso de editor desconocido o quedar bloqueado por tu política.

## Desarrollo

Node.js 22.22+, npm ci (ONNXRUNTIME_NODE_INSTALL_CUDA=skip), npm run build, npm start.
No ejecutes dos servidores contra la misma carpeta de datos. La app está destinada
al uso local individual, no a publicarse en Internet sin añadir controles de acceso.
Ver COMPARACION_Y_PRUEBAS.md para pruebas y límites realmente verificados.
Los documentos ORIGINAL_* son documentación de la base adjunta, no pruebas de esta versión.
