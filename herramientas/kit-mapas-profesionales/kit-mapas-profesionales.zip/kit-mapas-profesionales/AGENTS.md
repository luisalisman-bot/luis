# Instrucciones del proyecto

Lee primero START_HERE.md, PROJECT_CONTEXT.md y .agents/skills/mapas-profesionales/SKILL.md. Los demás skills están en .agents/skills/; su inventario y procedencia están en SKILLS_INDEX.md.

Trabaja dentro de este proyecto, usando out/ para las pruebas. Antes de publicar, revisa y valida el archivo real. Las grabaciones del usuario se colocan localmente en public/audio.mp3 y no se publican como parte del paquete. El estado del agente, las cuentas conectadas y las autorizaciones de otro chat no se transfieren por este archivo.

Para reproducir la base, usa el audio original y scripts/run.py. Para una historia o narración distinta, adapta datos, assets, subtítulos, escenas y project.json. Después de cambios intencionales, usa --skip-integrity al ejecutar el helper; el manifiesto identifica la distribución original.

Los scripts no publican automáticamente en servicios externos. Para entregar archivos usa las capacidades y la autorización disponibles en la conversación actual.
