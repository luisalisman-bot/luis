# Fuentes

Audio: MP3 original del usuario. Mapas: NASA Blue Marble incluido en la plantilla original; reproyección local de la imagen. Fronteras: Natural Earth / world-atlas instalado. Comparaciones: superficies aproximadas documentadas en la primera entrega. Tipografía: Open Sans, licencia OFL conservada en public/fonts. Efectos: síntesis local mediante Numpy/SciPy; música de la plantilla a nivel bajo. Las dos referencias del usuario se analizan; sus fotogramas no se insertan en el nuevo video.
