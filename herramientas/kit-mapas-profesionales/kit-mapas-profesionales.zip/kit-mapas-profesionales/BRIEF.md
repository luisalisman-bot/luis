# Revisión del video de tamaños

Petición: rehacer el video con acabado profesional tomando como referencias los dos MP4 aportados por el usuario. Añadir zooms, paneos, fronteras, efectos sincronizados y una edición cartográfica más cercana a las referencias. Conservar el audio español original completo de 35,47425 s. Vertical 1080×1920, 30 fps. Entrega en el GitHub ya autorizado, conservando la versión inicial.

Referencias: STYLE_REFERENCIAS.md. No usar objetos militares, árboles ni barcos porque no forman parte del guion. Las comparaciones de áreas son conceptuales y no un encaje físico de fronteras.
