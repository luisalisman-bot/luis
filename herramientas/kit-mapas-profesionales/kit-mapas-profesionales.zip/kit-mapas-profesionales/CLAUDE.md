# Continuidad para Claude

Este es un proyecto real de Remotion, no solo un prompt. Lee AGENTS.md, START_HERE.md, PROJECT_CONTEXT.md y .agents/skills/mapas-profesionales/SKILL.md antes de modificarlo.

Los skills de trabajo están incluidos en .agents/skills/. Puedes leerlos directamente. Si tu entorno exige .claude/skills, crea enlaces o copias locales a esas carpetas; no hace falta instalarlos globalmente.

Comprueba qué herramientas de archivos, terminal, imagen y audio tienes disponibles. Informa de un impedimento concreto si no puedes ejecutar Node/Python o abrir el MP3 adjunto. No presentes un plan o una simulación de código como si fuera un MP4 exportado.
