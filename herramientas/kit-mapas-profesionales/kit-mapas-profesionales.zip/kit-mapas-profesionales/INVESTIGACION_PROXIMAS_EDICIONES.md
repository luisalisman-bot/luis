# Investigación para próximas revisiones de mapas

Fecha: 2026-11-11. Alcance: recomendaciones para futuras ediciones. No se ha vuelto a renderizar ni reemplazado el MP4 aprobado de la versión 2.

## Fuentes primarias consultadas

- Google Earth Studio, Easing: https://earth.google.com/studio/docs/making-animations/easing/
- Google Earth Studio, Camera Target: https://earth.google.com/studio/docs/advanced-features/camera-target/
- Google Earth Studio, Multi-View: https://earth.google.com/studio/docs/advanced-features/multiview/
- Adobe Premiere, Automatically duck audio: https://helpx.adobe.com/premiere/desktop/add-audio-effects/adjust-volume-and-levels/automatically-duck-audio.html

## Hallazgos de las fuentes

Las curvas temporales de posición y orientación deben coordinarse para evitar tirones. Cuando existen puntos intermedios, la continuidad de la trayectoria merece revisión específica: suavizar la entrada y salida de cada tramo de forma aislada no garantiza un recorrido continuo. El objetivo de cámara permite mantener la atención sobre un punto mientras la cámara cambia de posición. La vista externa de las trayectorias ayuda a detectar rutas y giros inconvenientes. La atenuación de fondo debe relacionarse con la voz, con ajustes de sensibilidad, cantidad y tiempo de fundido; tras cambiar el montaje es necesario actualizar esa automatización.

## Aplicación editorial propuesta a nuestro flujo local

1. Separar el recorrido espacial de la cámara de su velocidad. Dar continuidad a los puntos intermedios y reservar las paradas completas para una cifra o lugar que necesite leerse.
2. Revisar en conjunto paneo, zoom, giro e inclinación para que no terminen a destiempo. No afirmar que el proyecto usa Earth Studio: estos principios pueden implementarse en Remotion.
3. Mantener círculos, flechas, límites y etiquetas en coordenadas del territorio. Verificar el encuadre al principio, a mitad y al final del movimiento.
4. Motivar cada cambio con una palabra o un cambio de idea. Alternar desplazamientos y momentos de observación, sin saturar todos los planos con el mismo zoom.
5. Usar recortes u objetos solo cuando ayuden a explicar el guion. No importar barcos, árboles o fortalezas del video de referencia si el tema no los requiere.
6. Organizar el sonido por función: voz, música, movimientos, revelaciones y ambientes. La voz conserva prioridad. Relacionar la atenuación con frases y pausas para evitar que el fondo suba y baje en cada sílaba.
7. Actualizar las señales de sonido después de retocar la duración o la curva de un movimiento. No tratar un número alto de efectos como una mejora por sí mismo.
8. Evaluar a tamaño de móvil la claridad del plano, los subtítulos y la miniatura. Conservar las proporciones reales en cualquier comparación de área.
9. Validar la exportación real: imágenes, audio, duración, contenedor, decodificación completa y copia publicada. Una prueba técnica no sustituye la revisión visual.

Estas aplicaciones son decisiones propuestas para este proyecto. No son reglas universales, mejoras ya renderizadas ni garantías de rendimiento en redes. No se instaló Google Earth Studio ni Adobe Premiere durante esta investigación.
