# Motion y sonido

Escenario continuo de satélite con proyección Mercator, límites de países de Natural Earth 50m para territorios seleccionados y 110m para contexto. Caminos de cámara definidos por fotograma, con interpolación suave y variación de escala, paneo, giro y perspectiva. Siluetas de comparación con proyección azimutal equivalente y textura muestreada de la misma fuente NASA. Los nombres permanecen asociados a posiciones geográficas.

Treinta y una señales de sonido generadas localmente y colocadas en segundos concretos: scripts/SOUND_CUES.json. Los desplazamientos tienen whoosh, los territorios europeos una señal corta, los datos un golpe suave y el espacio restante una campana breve. Los efectos se reducen durante los segmentos hablados mediante la envolvente RMS de la voz. No se ha sustituido la narración.

Subtítulos breves en la zona media/baja, blancos, sin cajas. Se conservan los tiempos de la alineación de la voz original. Revisar a tamaño real cualquier etiqueta de país, cada comparación y los extremos del encuadre.
