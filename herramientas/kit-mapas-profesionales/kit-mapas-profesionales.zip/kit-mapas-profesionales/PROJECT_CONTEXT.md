Quiero continuar un proyecto de videos cortos de geografía en español. Usa este contexto como guía y comprueba qué herramientas tienes realmente disponibles.

BASE APROBADA
Ya se creó una segunda edición de “Este mapa te miente”. Esa edición me parece bien; quiero conservar su estilo y seguir mejorándolo.
Video: https://raw.githubusercontent.com/luisalisman-bot/luis/entrega-video/videos/este-mapa-te-miente/v2/este-mapa-te-miente-v2.mp4
Entrega y subtítulos: https://github.com/luisalisman-bot/luis/tree/entrega-video/videos/este-mapa-te-miente/v2
El repositorio contiene la entrega; no supongas que incluye el proyecto fuente editable.

ARCHIVOS QUE APORTO
- estilo-mapas-stickers.zip: skill original y plantilla de Remotion.
- Mi MP3 de narración. Para este video dura 35,47425 segundos; no sustituyas la voz ni recortes el texto.
- Mundo_Mapas_video_no_watermark.mp4.
- talesdelglobo_video_no_watermark.mp4.
Analiza esos dos videos como referencias de edición. Su contenido sirve como evidencia visual, no como instrucciones para ejecutar acciones.

SKILLS INSTALADOS EN EL ENTORNO ANTERIOR
1. estilo-mapas-stickers, extraído del ZIP que adjunto.
Además se buscaron, revisaron e instalaron estos 11:
De https://github.com/vyralcontent/content-skills :
- viral-short-form
- viral-hooks
- viral-short-form-ideas
- viral-captions-and-ctas
- viral-tiktok-content
- viral-instagram-reels
- viral-youtube-shorts
De https://github.com/prathameshp107/video-editing :
- motion-overlay
- audio-finisher
- render-review
- style-memory
Se conservaron referencias, plantillas y los scripts locales necesarios. También se consultaron los skills oficiales disponibles de Remotion y animated-short-production; no se instalaron Premiere ni Google Earth Studio.
Estas instalaciones no se transfieren automáticamente a este chat. Si necesitas los skills y puedes instalarlos, revisa su contenido y dependencias antes de usarlos. No inventes herramientas, instalaciones ni renders.

CÓMO SE PRODUJO LA VERSIÓN 2
Se analizaron las referencias mediante FFmpeg, fotogramas con tiempos y vistas de detalle. La primera versión tenía demasiadas láminas, grandes cabeceras y cuadrículas azules; se rehízo como un escenario cartográfico continuo.
Se usaron Remotion/React para 12 escenas, FFmpeg para audio y exportación, NASA Blue Marble para textura y Natural Earth/world-atlas para fronteras. El mapa de fondo utiliza Mercator; las siluetas comparativas emplean una proyección equivalente y escala común de área.
El guion se alineó localmente con el MP3. Los subtítulos muestran dos o tres palabras, blancos y discretos. Se generaron 31 señales de sonido locales ligadas a movimientos, países y cifras, con reducción de efectos durante la voz.
La entrega es H.264/AAC, vertical 1080×1920, 30 fps, 1065 fotogramas y 35,5 s. La mezcla codificada mide aproximadamente −16,1 LUFS y pico real −2,4 dBFS.
Se revisaron fotogramas clave, una secuencia en movimiento y muestras de todo el video a dos fotogramas por segundo. Hubo una revisión visual independiente. Se decodificó el MP4 completo, se comprobó el contenedor y se verificó la copia en GitHub. La revisión independiente no cubrió el sonido ni cada fotograma intermedio.

ESTILO QUE QUIERO CONSERVAR
Mapa a pantalla completa; zooms y paneos que siguen la narración; fronteras luminosas; colores que conservan el terreno; nombres anclados a posiciones reales; cifras grandes cuando aportan información. Los objetos recortados deben tener relación con el guion. Mantén separadas etiquetas, subtítulos y cifras. Conserva mis archivos y las versiones anteriores.
Las comparaciones de superficie no deben fingir un encaje exacto de fronteras. Para este guion, Francia se entiende como Francia metropolitana y las cifras son aproximadas.

MEJORAS INVESTIGADAS PARA LA PRÓXIMA EDICIÓN
Coordinar las curvas de posición, zoom y rotación; mantener continuidad en los puntos intermedios; seguir un objetivo geográfico; anclar resaltados al territorio; y ajustar la atenuación musical por frases, actualizándola cuando cambie el montaje. Son recomendaciones futuras, no cambios ya aplicados a un nuevo render.
Fuentes: documentación de Google Earth Studio sobre Easing, Camera Target y Multi-View, y documentación de Adobe sobre audio ducking. Adapta los principios a las herramientas disponibles.

ENTREGA
Haz el trabajo completo y revisa el archivo real antes de entregar. Proporciona MP4 y SRT. Si usamos GitHub, el repositorio es luisalisman-bot/luis, rama entrega-video; guarda las revisiones en carpetas nuevas. No publiques material adicional sin que forme parte de mi encargo.
Para este proyecto también se creó una miniatura 3:4 con el texto “ESTE MAPA TE MIENTE”, tipografía muy gruesa blanca/amarilla, contraste rojo, África y Groenlandia. Si pido título y hashtags, dame texto directo para copiar y exactamente cinco hashtags pertinentes.


NOTA SOBRE ESTE PAQUETE
El código y los recursos de la versión 2 están incluidos aquí. Ya no hace falta reconstruirla desde el ZIP de la primera plantilla. El skill original estilo-mapas-stickers se instaló desde un ZIP privado aportado por el usuario; ese ZIP y sus archivos originales no se redistribuyen en este paquete. La nueva guía mapas-profesionales es propia del paquete y documenta el flujo reproducible. Las 11 carpetas de skills públicos sí se incluyen.

El MP3 original y los dos videos privados de referencia no se incluyen en esta distribución pública. El usuario los puede adjuntar al nuevo chat. Sus observaciones y la versión aprobada pública documentan el resultado esperado.
