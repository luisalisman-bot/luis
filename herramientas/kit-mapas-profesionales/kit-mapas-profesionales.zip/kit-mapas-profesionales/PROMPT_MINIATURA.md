# Miniatura aprobada

Archivo: assets/miniatura-3x4.png. Dimensiones comprobadas: 1086×1448, relación exacta 3:4.

Dirección visual: mapa satelital oscuro con África grande y dorada, Groenlandia pequeña en cian, bordes luminosos, flecha roja y sello ×14. Texto exacto en dos líneas: ESTE MAPA / TE MIENTE. Tipografía de pantalla extra gruesa y condensada, estilo Anton/Impact, blanco y amarillo, contorno oscuro y acento rojo. Mantener márgenes y lectura clara en móvil. El estilo es una intención visual, no una promesa de viralidad.

La miniatura se generó con una herramienta de generación de imágenes usando como referencia un fotograma de nuestro propio video. No se utilizó una imagen del creador de los videos de referencia. Para cambiarla, usa la herramienta de imagen disponible y revisa letras, proporción y recortes. No afirmes que otra aplicación tiene la misma herramienta si no está disponible.
