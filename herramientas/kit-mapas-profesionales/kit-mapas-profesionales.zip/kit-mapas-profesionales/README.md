# Kit de mapas profesionales para Claude, Muse y otros agentes

Proyecto editable de Remotion con recursos, tipografía, sonidos, miniatura 3:4, 11 skills públicos, una guía de producción propia, contexto de la edición aprobada y scripts de exportación/revisión.

1. Descomprime el paquete.
2. Abre START_HERE.md y PROJECT_CONTEXT.md.
3. Adjunta el MP3 original y pega PROMPT_PARA_CLAUDE_O_MUSE.txt en el nuevo chat.
4. El agente debe comprobar sus herramientas y seguir el flujo de muestra, revisión, exportación y validación.

La grabación original y los videos privados de referencia se adjuntan por separado. No hay claves de API ni cuentas conectadas en el kit. Para ejecutar la edición se necesita un entorno con archivos, terminal, Node.js, Python y un navegador compatible con Remotion.

La prueba documentada en evidence/package-check.json verificó la compilación, una muestra renderizada, su decodificación y la generación del SRT. No constituye una prueba de ejecución en todos los productos de chat.
