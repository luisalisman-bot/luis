# Revisión de la versión 2

Antes del render completo se revisaron 21 fotogramas clave, cinco encuadres corregidos y una secuencia de 4,4 segundos de Europa con audio. Se consultó un revisor independiente para los encuadres clave.

Corregido:
- La etiqueta de África en la comparación ×14 quedaba demasiado cerca del subtítulo: se elevó la silueta.
- Los textos flotantes heredaban un ancho estrecho y saltaban de línea: se definió su ancho máximo.
- Se eliminaron nombres repetidos en el área inferior de los recorridos por Europa y EEUU/China/India.
- Todas las siluetas de la suma utilizan una escala común. El texto aclara que no es un encaje de fronteras.
- Se eliminó la ubicación de México y Groenlandia como recortes sobre África en el cierre y se resaltan sus posiciones reales.
- El círculo polar estaba fijo en pantalla y se alejaba del territorio: se ancló a coordenadas del mapa y se reencuadró Groenlandia.
- Se extendió la franja de océano ártico para evitar un borde horizontal en el extremo de la textura Mercator.

Se revisaron las 71 muestras de la exportación completa a dos fotogramas por segundo. El revisor independiente no encontró nuevos problemas materiales fuera de una franja polar; se corrigió el encuadre de ese plano y se verificó de nuevo a tamaño grande. La nueva mezcla se midió aproximadamente a −16,15 LUFS, con pico real de −2,36 dBFS.

La copia final tiene 1065 fotogramas, 1080×1920, 30 fps y 35,5 s. La narración completa de 35,47425 s está incluida. Se decodificaron todos los fotogramas y el audio sin errores; se verificaron los átomos ftyp/moov/mdat y no se detectaron intervalos negros. La mezcla final codificada mide −16,1 LUFS y pico real −2,4 dBFS. La corrección polar se verificó sobre el MP4 final. Publicación completada en GitHub: commit 090bba730b3b03521c09aed547b66d2603205f38. Se verificaron el tamaño y el SHA del blob remoto del MP4 y del SRT contra los originales locales. La primera entrega permanece sin modificaciones.
