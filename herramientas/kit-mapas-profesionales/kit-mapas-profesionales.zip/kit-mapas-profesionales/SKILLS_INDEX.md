# Skills incluidos y procedencia

El paquete incluye una guía propia, mapas-profesionales, y estos 11 skills públicos. Se conservan sus referencias, fuentes y licencias presentes. Los scripts de audio y revisión se comprobaron con --help. No se ejecutaron instaladores de servicios de pago ni se configuraron credenciales.

- **viral-captions-and-ctas** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-hooks** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-instagram-reels** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-short-form** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-short-form-ideas** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-tiktok-content** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **viral-youtube-shorts** — https://github.com/vyralcontent/content-skills — commit `349e495d97029a3e6303a7510e3f39c73f36d8fe`.
- **motion-overlay** — https://github.com/prathameshp107/video-editing — commit `b344da99bfaeb496c048703b82bf1a034d732f2a`.
- **audio-finisher** — https://github.com/prathameshp107/video-editing — commit `b344da99bfaeb496c048703b82bf1a034d732f2a`.
- **render-review** — https://github.com/prathameshp107/video-editing — commit `b344da99bfaeb496c048703b82bf1a034d732f2a`.
- **style-memory** — https://github.com/prathameshp107/video-editing — commit `b344da99bfaeb496c048703b82bf1a034d732f2a`.

El entorno original también tenía el skill estilo-mapas-stickers, extraído del ZIP privado del usuario, y acceso a skills de Remotion del conector. No se asume que esos conectores estén instalados en otro chat. Remotion funciona aquí como dependencia de Node con versiones fijadas en package-lock.json.

Fuentes técnicas: https://www.remotion.dev/docs/ y los enlaces oficiales recogidos en INVESTIGACION_PROXIMAS_EDICIONES.md.
