# Empezar aquí

Este paquete contiene el código editable que produce la edición de mapas aprobada, los mapas y sus texturas, tipografía, sonidos, subtítulos, miniatura, notas de montaje y skills de trabajo. No incluye node_modules ni programas de edición instalados; las dependencias se obtienen con npm ci.

## Lo necesario

- Un entorno capaz de leer archivos y ejecutar terminal con Node.js 18+ y Python 3.10+.
- npm/npx e Internet para instalar dependencias cuando no estén presentes.
- Chromium/Chrome o el navegador administrado por Remotion.
- FFmpeg/FFprobe, del sistema o de los binarios incluidos con las dependencias de Remotion.
- El MP3 original que adjunta el usuario, si se quiere reproducir esta misma edición.

El paquete público no incluye la grabación original ni los dos videos de referencia. Se pueden adjuntar aparte. Para renderizar la edición aprobada basta con el MP3; los recursos visuales del montaje ya están incluidos.

## Orden de lectura

1. PROJECT_CONTEXT.md: historia, resultado aprobado y flujo empleado.
2. STYLE.md y STYLE_REFERENCIAS.md: preferencias y observaciones de las referencias.
3. SKILLS_INDEX.md y .agents/skills/mapas-profesionales/SKILL.md.
4. STORYBOARD.md, MOTION_PLAN.md, ASSET_PLAN.md y project.json.
5. src/MainV2.tsx, src/MapV2.tsx y los cuatro archivos src/Scene*V2.tsx.

## Comandos para esta edición

Ejecuta desde la raíz del paquete. En Windows, sustituye python3 por python si corresponde.

```bash
python3 scripts/run.py --check
python3 scripts/run.py --setup
python3 scripts/run.py --audio "/ruta/al/MP3_original.mp3" --stills
python3 scripts/run.py --sample
```

Revisa las imágenes de out/stills y la muestra out/sample.mp4. Para exportar y validar:

```bash
python3 scripts/run.py --render
```

El helper instala dependencias cuando faltan, exporta, ajusta el volumen, conserva la narración, genera SRT y valida el MP4. Produce out/este-mapa-te-miente.mp4, out/este-mapa-te-miente.srt, out/miniatura-3x4.png y los informes de revisión técnica. La inspección visual y de sonido sigue siendo trabajo del agente.

Si ya hiciste cambios intencionales al código, añade --skip-integrity a las siguientes ejecuciones. Si no hay un Chrome compatible, usa la instalación de navegador documentada por Remotion en ese entorno. No configures cuentas ni servicios de voz para reproducir esta edición.

## Para crear otro video

Este proyecto no convierte automáticamente cualquier audio en una edición nueva. El agente debe analizar el nuevo audio, verificar los datos, diseñar escenas y assets, actualizar subtítulos y los tiempos de todos los componentes y registrar la nueva duración en project.json y Root.tsx. El hash de audio evita usar por accidente el montaje anterior con otra narración. Actualízalo conscientemente después de preparar una línea temporal nueva.

Los scripts prepare-v2.mjs, textures-v2.py y sound-design-v2.py permiten regenerar la cartografía y los sonidos. Solo para esa regeneración se necesitan las dependencias opcionales de requirements-optional.txt. Los assets ya generados están incluidos.

## Distribución y evidencia

MANIFEST.json contiene hashes del paquete. evidence/ registra la validación de la entrega aprobada, no resultados de una ejecución nueva. Cada exportación debe producir sus propios informes. El encoder puede cambiar los bytes del MP4 entre versiones; compara resolución, fotogramas, contenido y sincronía, no prometas un hash idéntico al de la entrega anterior.

No se incluyen secretos, tokens, grabaciones privadas, referencias en video, caches ni rutas de autorización. Los scripts no publican en GitHub, Drive u otros servicios por sí solos.
