# Edición de la versión 2

| Segundos | Acción | Evidencia / sincronía |
|---|---|---|
|0–5|Viaje del mapa general al norte y resaltado de Groenlandia|Gancho de la voz original|
|5–7,7|Zoom a Groenlandia, borde luminoso y círculo de énfasis|Mira Groenlandia / parece enorme|
|7,7–10,9|Comparación con África en proyección equivalente y dato ×14|La cifra coincide con catorce veces|
|10,9–13,3|Recorrido sobre Rusia, nombre anclado y área|Nombre y descripción del país|
|13,3–15,6|Comparación real de Rusia y África|Casi dos; cifra precisa aproximada 1,8|
|15,6–17,5|Zoom al contorno de México|Y México|
|17,5–21,9|España, Francia, Alemania e Italia; regreso a México y suma|Cámaras en cada nombre según captions.json|
|21,9–23,5|Acercamiento al continente africano|Pero esto es lo más loco|
|23,5–27,7|EEUU, China, India; suma comparada con África|Efectos y cambios asociados a cada país|
|27,7–29,6|Área restante y arco proporcional de 25 %|Y todavía sobra espacio|
|29,6–32,4|Deformación en Mercator y énfasis polar|Los mapas deforman|
|32,4–35,47|Pregunta y llamada a comentar el país|Voz original sin recortes|
