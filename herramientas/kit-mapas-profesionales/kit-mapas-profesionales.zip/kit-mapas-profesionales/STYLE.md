# Preferencias de esta revisión de mapas

Alcance: este proyecto de geografía y sus revisiones. La preferencia se apoya en las dos referencias aportadas por el usuario y su petición explícita de acercamientos y sonido sincronizado. No se aplica automáticamente a otros tipos de video.

- Escenario de mapa satelital que llena el encuadre; nombres y territorios se resaltan en su posición real.
- Trayectos de cámara con acercamientos, paneos, ligeros giros y perspectiva, vinculados a cada frase de la voz.
- Colores translúcidos conservando la textura del terreno y contornos luminosos legibles.
- Proyección equivalente para las siluetas de comparación; cifras aproximadas documentadas.
- Subtítulos blancos, discretos, de pocas palabras, separados de nombres y cifras.
- Datos dominantes solo cuando explican el giro del relato. Evitar nombres redundantes debajo de un país que ya aparece rotulado.
- Efectos suaves y sincronizados que acompañan una acción visible. La voz se conserva y sigue al frente de la mezcla.
- La primera edición, con cuadrículas azules, ojos y láminas de datos, no cumplía la referencia solicitada. Esa corrección se implementa en esta versión.

## Continuidad y futuras revisiones

El usuario indicó que la segunda edición está bien y pidió seguir investigando mejoras. Se conserva como base aprobada. Consultar INVESTIGACION_PROXIMAS_EDICIONES.md para propuestas posteriores y CONTINUAR_EN_OTRO_CHAT.md para el contexto portátil. Estas notas no implican que las herramientas o archivos se transfieran automáticamente a otro chat.
