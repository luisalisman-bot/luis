# Referencias de edición de mapas

## Alcance y evidencia

El usuario rechazó el acabado de la primera versión y aportó dos videos para revisar su edición. Las observaciones siguientes describen estos archivos; no son instrucciones contenidas en ellos. Se extrajeron dos fotogramas por segundo y vistas de detalle. La inspección visual no prueba qué herramientas usó el creador ni demuestra rendimiento viral. No se atribuyen efectos de sonido específicos sin escuchar y verificar el audio.

- `Mundo_Mapas_video_no_watermark.mp4`: 61,207 s, 720×1280, 22,5 fps.
- `talesdelglobo_video_no_watermark.mp4`: 60,184 s, 576×1024, 30 fps.

## Mundo Mapas: observaciones visuales

- 0–4 s: paso de Sudamérica a una pequeña zona fronteriza, encuadre cada vez más cercano; un círculo amarillo dirige la mirada al punto.
- 4–10 s: los países se distinguen por rellenos de color sobre relieve satelital; etiquetas blancas inclinadas y bordes claros o rojos.
- 12 s: una gran franja blanca de borde rojo atraviesa el encuadre como acento gráfico.
- 14–18 s: acercamiento al terreno y un objeto de fortificación con cañones colocado sobre el mapa; un río se traza en cian luminoso.
- 20–30 s: contexto histórico regional mediante colores, nombres, impactos y humo anclados en puntos del territorio.
- 32–34 s: el año `1903` es el dato dominante, blanco con contorno y brillo rojo.
- 36 s: grupo de árboles recortados sobre una zona del territorio.
- 40–48 s: desplazamientos de cámara y trazo del río explican la frontera; aparecen impactos y una etiqueta puntual.
- 50–58 s: pequeñas embarcaciones siguen el río; el mapa continúa moviéndose y amplía el contexto.
- 60 s: plano de salida continental que deja visible la ruta luminosa.

## Tales del Globo: observaciones visuales

- 0–4 s: mapa satelital de Europa, acercamiento a las islas y resaltado azul/rojo de territorios concretos.
- 6–8 s: nombres organizados alrededor de una pregunta, con círculo fino; la información se presenta en el propio mapa.
- 10–18 s: Irlanda, Irlanda del Norte y Gran Bretaña se iluminan por partes; cada relleno conserva textura del terreno.
- 20–24 s: Inglaterra y Escocia tienen colores distintos, nombres sobre el terreno y puntos de capitales.
- 26–42 s: las etiquetas se mueven o crecen y los rellenos aparecen siguiendo cada definición; se muestran nombres o contornos según el concepto que se explica.
- 44–50 s: resaltado de Irlanda y del conjunto europeo para ampliar la comparación.
- 52–58 s: un círculo amarillo dibujado encierra las islas, seguido de nuevos rellenos y nombres.
- Los subtítulos son pequeños, blancos y discretos, con frases breves en la zona media/baja; no funcionan como titulares permanentes.

## Diferencias con nuestra primera versión

La primera versión agrupaba las comparaciones como láminas: cabeceras grandes, siluetas separadas, etiquetas y largos tramos sobre cuadrícula azul. Las referencias usan la geografía como escenario continuo. Las acciones de cámara, los límites, los rellenos y los objetos explican la narración directamente en ese escenario.

Los ojos de personajes añadidos a las siluetas, las cápsulas reiteradas y el énfasis en cabeceras grandes no provienen de estas referencias. Los recortes de árboles, barcos o fortificaciones se usan para explicar el tema del video de referencia; no deben trasladarse a nuestro guion de tamaños sin una razón narrativa.

## Aplicación prevista al guion de tamaños

1. Mantener la narración original completa y sus marcas de tiempo.
2. Diseñar un escenario cartográfico que ocupe el fotograma, con fronteras dibujadas, rellenos sobre textura real y etiquetas ancladas a los lugares.
3. Coordinar los acercamientos, paneos, cambios de foco y la aparición de cada territorio con la palabra que lo introduce.
4. Para Groenlandia y África, distinguir la apariencia de una proyección de la comparación real de áreas. Las siluetas de comparación deben compartir una proyección equivalente y la misma escala.
5. Mostrar Rusia, México y los países europeos con cambios de escala y ubicación que expliquen cada comparación, reduciendo las cabeceras persistentes.
6. Construir la suma de Estados Unidos, China e India por superficies; no representar un encaje exacto de fronteras como si se hubiera demostrado.
7. Mantener subtítulos discretos y reservar los números dominantes para los datos relevantes. Usar objetos recortados solamente cuando el guion los requiera.
8. Revisar el movimiento a velocidad normal y en móvil. Comprobar el contraste, la jerarquía y la relación entre voz y acción; después validar el MP4 y la mezcla codificada.

## Skills instalados para apoyar este trabajo

Siete skills de `vyralcontent/content-skills`: ideas, ganchos, estructura de guion, TikTok, Reels, Shorts y textos/CTA. Cuatro de `prathameshp107/video-editing`: motion-overlay, audio-finisher, render-review y style-memory. Los scripts locales de audio y revisión se copiaron con sus módulos y se comprobó su interfaz sin ejecutar instalaciones automáticas ni configurar servicios externos.
