# Procedencia de recursos

- Cartografía: NASA Blue Marble, procedente del recurso que aportó el usuario en la primera plantilla; reproyección y texturas de territorios generadas localmente. Fronteras: Natural Earth, vía world-atlas.
- Open Sans: conservar public/fonts/OFL-OpenSans.txt al redistribuir la fuente.
- Siete skills viral-*: Vyral, licencia MIT, con LICENSE y archivos de procedencia en sus carpetas.
- Cuatro skills de edición y scripts de audio/revisión: prathameshp107/video-editing. Se conserva su procedencia en INSTALL_SOURCE.json; las licencias presentes en el origen se conservan y no se atribuye una licencia nueva a todo el paquete.
- Música de trabajo: sintetizada localmente mediante el generador de la plantilla original. Señales de sonido de la revisión 2: síntesis local de cinco familias de efectos, con 31 eventos registrados en scripts/SOUND_CUES.json.
- La plantilla privada original y los videos originales de referencia no se incluyen. Los archivos en evidence/ son resultados históricos de la producción anterior.
