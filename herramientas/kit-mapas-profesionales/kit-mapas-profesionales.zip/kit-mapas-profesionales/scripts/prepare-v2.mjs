import fs from 'node:fs';
import {feature,merge} from 'topojson-client';
import {geoMercator,geoAzimuthalEqualArea,geoPath,geoStream,geoCentroid} from 'd3-geo';
const atlas=JSON.parse(fs.readFileSync('node_modules/world-atlas/countries-50m.json'));
const simple=JSON.parse(fs.readFileSync('node_modules/world-atlas/countries-110m.json'));
const countries=feature(atlas,atlas.objects.countries).features;
const get=id=>countries.find(f=>f.id===id);
const african=new Set('012 024 072 108 120 132 140 148 174 178 180 204 226 231 232 262 266 270 288 324 384 404 426 430 434 450 454 466 478 480 504 508 516 562 566 624 638 646 654 678 686 690 694 706 710 716 728 729 732 748 768 788 800 818 834 854 894'.split(' '));
const africa={type:'Feature',geometry:merge(atlas,atlas.objects.countries.geometries.filter(g=>african.has(g.id)||g.properties.name==='Somaliland')),properties:{name:'Africa'}};
const defs={africa:[africa,[20,0],30.37,'ÁFRICA'],greenland:[get('304'),[-42,72],2.166,'GROENLANDIA'],russia:[get('643'),[100,60],17.098,'RUSIA'],mexico:[get('484'),[-102,23],1.964,'MÉXICO'],usa:[get('840'),[-100,43],9.834,'ESTADOS UNIDOS'],china:[get('156'),[104,35],9.597,'CHINA'],india:[get('356'),[79,22],3.287,'INDIA'],spain:[get('724'),[-4,40],.506,'ESPAÑA'],france:[get('250'),[2,47],.552,'FRANCIA'],germany:[get('276'),[10,51],.357,'ALEMANIA'],italy:[get('380'),[12.5,42.5],.301,'ITALIA']};
const fr=defs.france[0];fr.geometry={...fr.geometry,coordinates:fr.geometry.coordinates.filter(poly=>poly.flat(1).every(p=>p[0]>-10&&p[0]<15))};
const merc=geoMercator().scale(5400/(2*Math.PI)).translate([2700,2700]).clipExtent([[0,0],[5400,5400]]);
const path=geoPath(merc);
const out={regions:{},borders:feature(simple,simple.objects.countries).features.map(f=>({d:path(f)}))};
for(const [id,[f,center,area,name]]of Object.entries(defs)){
 const projection=geoAzimuthalEqualArea().rotate([-center[0],-center[1]]).scale(1).translate([0,0]);
 const p=geoPath(projection);projection.scale(Math.sqrt(10000/p.area(f)));
 let bounds=p.bounds(f);projection.translate([-(bounds[0][0]+bounds[1][0])/2,-(bounds[0][1]+bounds[1][1])/2]);bounds=p.bounds(f);
 const rings=[];const sink={point(x,y){rings[rings.length-1].push([x,y]);},lineStart(){rings.push([]);},lineEnd(){},polygonStart(){},polygonEnd(){},sphere(){}};
 geoStream(f,projection.stream(sink));
 out.regions[id]={name,center,area,d:path(f),normalized:p(f),bounds,rings,projectionScale:projection.scale(),projectionTranslate:projection.translate(),centroid:geoCentroid(f)};
}
fs.writeFileSync('src/geo-v2.json',JSON.stringify(out));
console.log('Detailed countries and equal-area projections prepared');
