"""Portable setup, preview, rendering and delivery validation for this project."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
CONFIG = json.loads((ROOT / 'project.json').read_text(encoding='utf-8'))

def execute(args, capture=False):
    print('+', ' '.join(str(a) for a in args), flush=True)
    return subprocess.run([str(a) for a in args], cwd=ROOT, check=True,
                          text=True, capture_output=capture)

def resolve_binary(name):
    system = shutil.which(name)
    if system:
        return system
    for p in (ROOT / 'node_modules' / '@remotion').glob('compositor-*'):
        for suffix in ['', '.exe']:
            candidate = p / (name + suffix)
            if candidate.is_file():
                os.environ['PATH'] = str(p) + os.pathsep + os.environ.get('PATH', '')
                return str(candidate)
    raise RuntimeError(f'{name} no está disponible. Instala FFmpeg o las dependencias de Remotion.')

def browser_path():
    for name in ['chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable']:
        path = shutil.which(name)
        if path:
            return path
    for path in ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                 r'C:\Program Files\Google\Chrome\Application\chrome.exe']:
        if Path(path).is_file():
            return path
    return None

def cpu_count():
    count = os.cpu_count() or 1
    try:
        quota, period = Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if quota != 'max':
            count = min(count, max(1, int(quota) // int(period)))
    except (OSError, ValueError):
        pass
    return max(1, min(2, count))

def verify_package():
    manifest = ROOT / 'MANIFEST.json'
    if not manifest.is_file():
        return
    for item in json.loads(manifest.read_text())['files']:
        p = ROOT / item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != item['sha256']:
            raise RuntimeError(f'Archivo modificado o ausente: {item["path"]}. '
                               'Si estás editando el proyecto, usa --skip-integrity para las siguientes pruebas.')

def install_dependencies():
    if not shutil.which('node') or not shutil.which('npm') or not shutil.which('npx'):
        raise RuntimeError('Se necesita Node.js 18+ con npm y npx.')
    version = subprocess.check_output(['node', '-v'], text=True).strip()
    if int(version.lstrip('v').split('.')[0]) < 18:
        raise RuntimeError('La versión de Node.js debe ser 18 o superior.')
    if not (ROOT / 'node_modules' / '.bin' / 'remotion').exists():
        execute(['npm', 'ci', '--no-audit', '--no-fund'])
    execute(['npx', 'tsc', '--noEmit'])

def prepare_audio(path):
    target = ROOT / 'public' / 'audio.mp3'
    if path:
        source = Path(path).expanduser().resolve()
        if not source.is_file():
            raise RuntimeError('No se encuentra el MP3 indicado.')
        expected = CONFIG.get('approved_audio_sha256')
        if expected and hashlib.sha256(source.read_bytes()).hexdigest() != expected:
            raise RuntimeError('Este audio es diferente del audio aprobado. Para un audio nuevo, '
                               'el agente debe actualizar captions.json, escenas y project.json antes de renderizar.')
        if source != target.resolve():
            shutil.copy2(source, target)
    if not target.is_file():
        raise RuntimeError('Adjunta el MP3 original y ejecuta --audio /ruta/al/archivo.mp3. '
                           'El paquete público no contiene la grabación original.')
    if CONFIG.get('approved_audio_sha256'):
        if hashlib.sha256(target.read_bytes()).hexdigest() != CONFIG['approved_audio_sha256']:
            raise RuntimeError('El audio no coincide con la línea temporal aprobada.')

def remotion(output, extras=None):
    command = ['npx', 'remotion', 'render', 'src/index.ts', CONFIG['composition'], str(output),
               f'--concurrency={cpu_count()}']
    browser = browser_path()
    if browser:
        command.append('--browser-executable=' + browser)
    command += extras or []
    execute(command)

def create_srt(output):
    captions = json.loads((ROOT / 'public/captions.json').read_text(encoding='utf-8'))
    phrases, current = [], []
    for i, word in enumerate(captions):
        current.append(word)
        next_start = captions[i + 1]['startMs'] if i + 1 < len(captions) else word['endMs']
        if len(current) >= 3 or word['text'].strip().endswith(('.', ',', '?', '!', ':', ';', '…')) or next_start - word['endMs'] > 180:
            phrases.append(current)
            current = []
    if current:
        phrases.append(current)
    def stamp(value):
        h, rem = divmod(round(value), 3600000)
        m, rem = divmod(rem, 60000)
        s, ms = divmod(rem, 1000)
        return f'{h:02}:{m:02}:{s:02},{ms:03}'
    output.write_text('\n\n'.join(
        f'{i+1}\n{stamp(p[0]["startMs"])} --> {stamp(p[-1]["endMs"])}\n'
        + ' '.join(w['text'].strip() for w in p)
        for i, p in enumerate(phrases)) + '\n', encoding='utf-8')

def validate_video(video):
    ffmpeg, ffprobe = resolve_binary('ffmpeg'), resolve_binary('ffprobe')
    meta = json.loads(execute([ffprobe, '-v', 'error', '-count_frames', '-show_streams',
                               '-show_format', '-of', 'json', video], capture=True).stdout)
    v = next(s for s in meta['streams'] if s['codec_type'] == 'video')
    assert any(s['codec_type'] == 'audio' for s in meta['streams']), 'Falta el audio'
    assert (v['width'], v['height']) == (CONFIG['width'], CONFIG['height'])
    assert int(v['nb_read_frames']) == CONFIG['frames'], 'Número de fotogramas inesperado'
    assert abs(float(meta['format']['duration']) - CONFIG['frames'] / CONFIG['fps']) < .12
    atoms = []
    with video.open('rb') as f:
        total = video.stat().st_size
        while f.tell() < total:
            head = f.read(8)
            assert len(head) == 8
            size, kind = struct.unpack('>I4s', head)
            header = 8
            if size == 1:
                size = struct.unpack('>Q', f.read(8))[0]
                header = 16
            if size == 0:
                size = total - f.tell() + header
            assert size >= header and f.tell() + size - header <= total
            atoms.append(kind.decode('ascii'))
            f.seek(size - header, 1)
        assert f.tell() == total
    assert all(kind in atoms for kind in ['ftyp', 'moov', 'mdat'])
    check = execute([ffmpeg, '-hide_banner', '-loglevel', 'info', '-xerror', '-i', video,
                     '-vf', 'blackdetect=d=0.02:pix_th=0.02', '-f', 'null', '-'], capture=True)
    assert 'black_start:' not in check.stderr, 'Revisar intervalo negro detectado'
    report = {'file': video.name, 'bytes': video.stat().st_size,
              'sha256': hashlib.sha256(video.read_bytes()).hexdigest(),
              'duration': meta['format']['duration'], 'frames': v['nb_read_frames'],
              'dimensions': [v['width'], v['height']], 'atoms': atoms,
              'full_decode_ok': True, 'black_intervals': False}
    report_path = ROOT / 'out' / 'validation.json'
    report_path.parent.mkdir(exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--setup', action='store_true')
    parser.add_argument('--audio', help='Ruta al MP3 original que adjunta el usuario')
    parser.add_argument('--stills', action='store_true')
    parser.add_argument('--sample', action='store_true')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--skip-integrity', action='store_true', help='Usar después de editar código')
    parser.add_argument('--validate', type=Path, help='Validar un MP4 ya exportado')
    args = parser.parse_args()
    if not args.skip_integrity:
        verify_package()
    if args.validate:
        print(json.dumps(validate_video(args.validate.resolve()), indent=2))
        return
    if args.setup or args.stills or args.sample or args.render:
        install_dependencies()
    if args.audio or args.stills or args.sample or args.render:
        prepare_audio(args.audio)
    out = ROOT / 'out'
    out.mkdir(exist_ok=True)
    if args.stills:
        remotion(out / 'stills', ['--frames=' + ','.join(str(f) for f in CONFIG['key_frames']),
                                  '--image-format=jpeg', '--scale=.5'])
    if args.sample:
        a, b = CONFIG['sample_frames']
        remotion(out / 'sample.mp4', [f'--frames={a}-{b}', '--scale=.5', '--crf=21'])
    if args.render:
        ffmpeg = resolve_binary('ffmpeg')
        raw, normalized = out / 'raw.mp4', out / 'normalized.mp4'
        final = out / (CONFIG['output_stem'] + '.mp4')
        if final.exists():
            raise RuntimeError('La entrega ya existe. Crea una carpeta de salida nueva para conservarla.')
        remotion(raw, ['--codec=h264', '--crf=18', '--pixel-format=yuv420p', '--audio-bitrate=192k'])
        execute([sys.executable, 'scripts/audio_finish.py', 'normalize', raw, normalized,
                 '--target', CONFIG['target_lufs'], '--true-peak', CONFIG['true_peak_limit'],
                 '--out', out / 'audio-report.json'])
        execute([ffmpeg, '-v', 'error', '-i', normalized, '-t', CONFIG['audio_seconds'],
                 '-map', '0', '-c', 'copy', '-movflags', '+faststart', final])
        create_srt(out / (CONFIG['output_stem'] + '.srt'))
        report = validate_video(final)
        execute([sys.executable, 'scripts/audio_finish.py', 'analyze', final,
                 '--target', CONFIG['target_lufs'], '--true-peak', CONFIG['true_peak_limit'],
                 '--out', out / 'audio-final.json'])
        shutil.copy2(ROOT / 'assets/miniatura-3x4.png', out / 'miniatura-3x4.png')
        print(json.dumps({'delivery': report, 'review_required': 'Revisar imagen y sonido antes de publicar'}, indent=2))
    if args.check or not any([args.setup, args.stills, args.sample, args.render, args.audio]):
        print(json.dumps({'source_ok': True, 'node': shutil.which('node'),
                          'npm': shutil.which('npm'), 'ffmpeg': shutil.which('ffmpeg'),
                          'browser': browser_path(), 'audio_present': (ROOT / 'public/audio.mp3').is_file(),
                          'composition': CONFIG['composition'], 'concurrency': cpu_count()}, indent=2))

if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError, AssertionError) as exc:
        print('ERROR:', str(exc), file=sys.stderr)
        sys.exit(1)
