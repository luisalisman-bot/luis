from pathlib import Path
import numpy as np
from scipy import signal
import wave,json,subprocess
root=Path(__file__).resolve().parent.parent
sr=48000;duration=35.47425
mix=np.zeros((round(duration*sr),2),dtype=np.float64)
rng=np.random.default_rng(1764)
def envelope(t,total,attack=.02):return np.minimum(1,t/attack)*np.maximum(0,1-t/total)**1.5
def make(kind):
 if kind=='fly':
  length=.44;t=np.arange(round(length*sr))/sr
  noise=signal.sosfilt(signal.butter(3,[220,5400],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,len(t)))
  env=np.sin(np.pi*t/length)**2
  sound=noise*env*.55+np.sin(2*np.pi*(170*t-90*t*t/length))*env*.1
 elif kind=='tap':
  length=.11;t=np.arange(round(length*sr))/sr
  sound=np.sin(2*np.pi*1020*t)*np.exp(-t*65)*.65+signal.sosfilt(signal.butter(2,6200,fs=sr,output='sos'),rng.normal(0,1,len(t)))*np.exp(-t*100)*.25
 elif kind=='reveal':
  length=.48;t=np.arange(round(length*sr))/sr
  sound=(np.sin(2*np.pi*(95*t-45*t*t/length))*.65+np.sin(2*np.pi*190*t)*.15)*np.exp(-t*12)*np.minimum(1,t/.008)
 elif kind=='scan':
  length=.50;t=np.arange(round(length*sr))/sr
  sound=signal.chirp(t,350,length,1650)*envelope(t,length,.04)*.35+signal.sosfilt(signal.butter(2,[1600,4200],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,len(t)))*envelope(t,length)*.13
 else:
  length=.65;t=np.arange(round(length*sr))/sr
  sound=(np.sin(2*np.pi*587.3*t)+.45*np.sin(2*np.pi*880*t))*np.exp(-t*7)*np.minimum(1,t/.008)
 return sound/(np.max(np.abs(sound))+1e-12)*.8
events=[
 (.02,'reveal',.10,0,'apertura'),(.63,'fly',.10,-.2,'acercamiento al norte'),(2.9,'tap',.06,0,'círculo del tamaño'),
 (4.997,'fly',.12,-.1,'zoom Groenlandia'),(6.196,'scan',.07,0,'círculo enorme'),(7.697,'fly',.11,.3,'viaje a África'),(8.805,'reveal',.14,0,'dato catorce veces'),
 (10.879,'fly',.11,.4,'Rusia'),(11.45,'scan',.06,0,'frontera Rusia'),(13.293,'fly',.11,-.3,'comparación África Rusia'),(13.88,'reveal',.11,0,'1,8 veces'),
 (15.645,'fly',.11,-.4,'México'),(17.521,'fly',.10,.4,'viaje a Europa'),(18.232,'tap',.085,-.3,'España'),(18.91,'tap',.085,-.1,'Francia'),(19.624,'tap',.085,.15,'Alemania'),(20.28,'tap',.085,.3,'Italia'),(20.848,'fly',.10,-.4,'suma y regreso'),(21.12,'reveal',.08,0,'México mayor'),
 (21.928,'fly',.11,.3,'África'),(22.45,'scan',.06,0,'círculo África'),(23.463,'fly',.11,-.3,'Estados Unidos'),(24.443,'fly',.10,.35,'China'),(24.922,'fly',.09,-.1,'India'),(25.415,'fly',.11,-.4,'suma continental'),(26.4,'reveal',.10,0,'suma 22,72'),
 (27.679,'ding',.10,0,'espacio restante'),(29.555,'fly',.10,-.3,'proyección Mercator'),(30.2,'scan',.06,0,'deformación polar'),(32.406,'fly',.095,.2,'pregunta final'),(33.683,'tap',.085,0,'comenta tu país')]
for at,kind,gain,pan,label in events:
 s=make(kind);i=round(at*sr);n=min(len(s),len(mix)-i)
 mix[i:i+n,0]+=s[:n]*gain*np.sqrt((1-pan)/2)
 mix[i:i+n,1]+=s[:n]*gain*np.sqrt((1+pan)/2)
# Duck effects during voiced syllables. The original narration is never edited.
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(root/'public/audio.mp3'),'-f','f32le','-ar',str(sr),'-ac','1','-'])
voice=np.frombuffer(raw,np.float32);vo=np.zeros(len(mix));vo[:min(len(vo),len(voice))]=voice[:len(vo)]
rms=np.sqrt(signal.convolve(vo*vo,np.ones(2400)/2400,mode='same',method='fft'))
duck=1-.27*np.clip((rms-.013)/.09,0,1)
mix*=duck[:,None];mix[-7200:]*=np.linspace(1,0,7200)[:,None]
def write(path,data):
 with wave.open(str(path),'wb')as out:
  out.setnchannels(2);out.setsampwidth(2);out.setframerate(sr);out.writeframes((np.clip(data,-1,1)*32767).astype('<i2').tobytes())
write(root/'public/sfx-v2.wav',mix)
(root/'scripts/SOUND_CUES.json').write_text(json.dumps([{'second':at,'type':kind,'gain':g,'pan':p,'visual':label}for at,kind,g,p,label in events],ensure_ascii=False,indent=2))
print('Designed',len(events),'synchronized local sound cues; peak',20*np.log10(np.max(np.abs(mix))))
