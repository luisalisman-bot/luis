from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import map_coordinates

root=Path(__file__).resolve().parent.parent
source=np.asarray(Image.open(root/'public/maps/bluemarble.jpg').convert('RGB'))
sh,sw=source.shape[:2]
# Inverse Mercator: the same projection used for all geographic overlays.
out=np.empty((5400,5400,3),dtype=np.uint8)
ys=sh/2-np.degrees(np.arctan(np.sinh((2700-np.arange(5400))/(5400/(2*np.pi)))))*sh/180
for y,sy in enumerate(ys):
 lo=int(np.floor(sy));hi=min(sh-1,lo+1);a=sy-lo
 out[y]=(source[lo]*(1-a)+source[hi]*a).astype(np.uint8)
Image.fromarray(out).save(root/'public/maps/mercator.jpg',quality=92)
del out

geo=json.loads((root/'src/geo-v2.json').read_text())
dest=root/'public/territories';dest.mkdir(exist_ok=True)
for key,s in geo['regions'].items():
 (x0,y0),(x1,y1)=s['bounds'];unit=max(x1-x0,y1-y0)/1050
 w=math.ceil((x1-x0)/unit);h=math.ceil((y1-y0)/unit)
 xx,yy=np.meshgrid(x0+(np.arange(w)+.5)*unit,y0+(np.arange(h)+.5)*unit)
 tx,ty=s['projectionTranslate'];k=s['projectionScale']
 x=(xx-tx)/k;y=-(yy-ty)/k
 rho=np.hypot(x,y);c=2*np.arcsin(np.minimum(rho/2,1));sinc=np.sin(c);cosc=np.cos(c)
 lon0,lat0=np.radians(s['center']);safe=np.maximum(rho,1e-9)
 lat=np.arcsin(np.clip(cosc*np.sin(lat0)+y*sinc*np.cos(lat0)/safe,-1,1))
 lon=lon0+np.arctan2(x*sinc,safe*np.cos(lat0)*cosc-y*np.sin(lat0)*sinc)
 coords=[(90-np.degrees(lat))*sh/180,((np.degrees(lon)+180)%360)*sw/360]
 rgb=np.stack([map_coordinates(source[:,:,i],coords,order=1,mode='nearest')for i in range(3)],axis=-1).astype(np.uint8)
 mask=Image.new('L',(w,h));draw=ImageDraw.Draw(mask)
 def signed(r):return sum(r[i-1][0]*r[i][1]-r[i][0]*r[i-1][1] for i in range(len(r)))
 largest=max(s['rings'],key=lambda r:abs(signed(r)));sign=1 if signed(largest)>0 else -1
 for ring in sorted(s['rings'],key=lambda r:abs(signed(r)),reverse=True):
  points=[((a-x0)/unit,(b-y0)/unit)for a,b in ring]
  if len(points)>2:draw.polygon(points,fill=255 if signed(ring)*sign>0 else 0)
 rgba=Image.fromarray(rgb).convert('RGBA');rgba.putalpha(mask);rgba.save(dest/(key+'.png'))
 print(key,w,h,flush=True)
