import React from 'react';
import {AbsoluteFill,Audio,Img,Series,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {HookV2,GreenlandV2,RussiaV2,MexicoV2} from './SceneOpeningV2';
import {AfricaGreenlandV2,AfricaRussiaV2,EuropeMexicoV2} from './SceneComparisonsV2';
import {LeadV2,SumV2,SpaceV2} from './SceneSumV2';
import {ProjectionV2,EndingV2} from './SceneEndingV2';
import {geo,L} from './MapV2';
import captions from '../public/captions.json';
export const GlobalFonts:React.FC=()=> <style>{`@font-face{font-family:OpenSans;src:url('${staticFile('fonts/OpenSans.ttf')}');font-weight:300 900;font-display:block}`}</style>;
const phrases:{text:string;start:number;end:number}[]=[];
let group:typeof captions=[];
const flush=()=>{if(group.length){phrases.push({text:group.map(x=>x.text.trim()).join(' '),start:group[0].startMs,end:group[group.length-1].endMs});group=[];}};
captions.forEach((c,i)=>{group.push(c);if(group.length===3||/[.,!?;:…]$/.test(c.text)||((captions[i+1]?.startMs??c.endMs)-c.endMs>180))flush();});flush();
const Subtitles:React.FC=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const ms=f/fps*1000;const p=phrases.find((p,i)=>ms>=p.start&&ms<Math.min(p.end+100,phrases[i+1]?.start??Infinity));return p?<div style={{position:'absolute',left:100,top:1300,width:880,textAlign:'center',color:'white',fontFamily:'OpenSans',fontWeight:700,fontSize:44,lineHeight:1.22,textShadow:'0 2px 6px #031c32,0 0 14px #031c32'}}>{p.text.replace(/[¡¿]/g,'').replace(/[.!?…]+$/,'').toLowerCase()}</div>:null;};
export const MainV2:React.FC=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#123a49',overflow:'hidden',fontFamily:'OpenSans'}}><GlobalFonts/>
 <AbsoluteFill style={{opacity:0,pointerEvents:'none'}}>{Object.keys(geo.regions).map(key=><Img key={key} src={staticFile(`territories/${key}.png`)} style={{width:1,height:1}}/>)}</AbsoluteFill>
 <Series>
  <Series.Sequence name="La ilusión del mapa" durationInFrames={150} premountFor={fps}><HookV2/></Series.Sequence>
  <Series.Sequence name="Zoom Groenlandia" durationInFrames={81} premountFor={fps}><GreenlandV2/></Series.Sequence>
  <Series.Sequence name="La escala real: África ×14" durationInFrames={95} premountFor={fps}><AfricaGreenlandV2/></Series.Sequence>
  <Series.Sequence name="Recorrido por Rusia" durationInFrames={73} premountFor={fps}><RussiaV2/></Series.Sequence>
  <Series.Sequence name="1,8 Rusias por superficie" durationInFrames={70} premountFor={fps}><AfricaRussiaV2/></Series.Sequence>
  <Series.Sequence name="Zoom México" durationInFrames={57} premountFor={fps}><MexicoV2/></Series.Sequence>
  <Series.Sequence name="Recorrido por cuatro países europeos" durationInFrames={132} premountFor={fps}><EuropeMexicoV2/></Series.Sequence>
  <Series.Sequence name="Acercamiento a África" durationInFrames={46} premountFor={fps}><LeadV2/></Series.Sequence>
  <Series.Sequence name="EEUU, China e India" durationInFrames={126} premountFor={fps}><SumV2/></Series.Sequence>
  <Series.Sequence name="25 por ciento restante" durationInFrames={57} premountFor={fps}><SpaceV2/></Series.Sequence>
  <Series.Sequence name="Explicación Mercator" durationInFrames={85} premountFor={fps}><ProjectionV2/></Series.Sequence>
  <Series.Sequence name="Comenta tu país" durationInFrames={93} premountFor={fps}><EndingV2/></Series.Sequence>
 </Series><Subtitles/>
 <Audio src={staticFile('audio.mp3')} volume={1}/>
 <Audio src={staticFile('sfx-v2.wav')} volume={1}/>
 <Audio src={staticFile('sfx/music.wav')} volume={f=>.028*L(f,0,25)*L(f,1035,1065,1,0)}/>
 </AbsoluteFill>;};
