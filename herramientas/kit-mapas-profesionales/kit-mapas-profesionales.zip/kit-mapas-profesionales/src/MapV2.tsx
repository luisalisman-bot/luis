import React from 'react';
import {AbsoluteFill,Img,interpolate,Easing,spring,staticFile,useCurrentFrame} from 'remotion';
import geo from './geo-v2.json';
export type Region=keyof typeof geo.regions;
export const C={yellow:'#ffe253',red:'#ff6452',cyan:'#44d9ff',mint:'#68ff9f',purple:'#ceadff',white:'#fffef5',ink:'#092335'};
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const ease=Easing.bezier(.42,0,.2,1);
export const L=(f:number,a:number,b:number,x=0,y=1)=>interpolate(f,[a,b],[x,y],clamp);
export const P=(f:number,delay=0)=>spring({frame:f-delay,fps:30,config:{damping:19,stiffness:180,mass:.65}});
export type Cam={lon:number;lat:number;zoom:number;rot?:number;tilt?:number};
export type Key=Cam&{at:number};
export const camera=(f:number,keys:Key[]):Cam=>{
 if(f<=keys[0].at)return keys[0];
 const last=keys[keys.length-1];if(f>=last.at)return last;
 const i=keys.findIndex((k,j)=>j<keys.length-1&&f>=k.at&&f<keys[j+1].at);const a=keys[i],b=keys[i+1];
 const t=interpolate(f,[a.at,b.at],[0,1],{...clamp,easing:ease});
 return {lon:a.lon+(b.lon-a.lon)*t,lat:a.lat+(b.lat-a.lat)*t,zoom:Math.exp(Math.log(a.zoom)+(Math.log(b.zoom)-Math.log(a.zoom))*t),rot:(a.rot??0)+((b.rot??0)-(a.rot??0))*t,tilt:(a.tilt??0)+((b.tilt??0)-(a.tilt??0))*t};
};
export const merc=(lon:number,lat:number):[number,number]=>[(lon+180)*15,2700-Math.log(Math.tan(Math.PI/4+Math.max(-85,Math.min(85,lat))*Math.PI/360))*5400/(2*Math.PI)];
export type Mark={id:Region;color:string;amount?:number;label?:boolean;draw?:number;opacity?:number;labelAt?:[number,number];labelSize?:number};
export const Atlas:React.FC<{cam:Cam;marks?:Mark[];rings?:{lon:number;lat:number;rx:number;ry:number;color:string;draw:number}[];muted?:boolean;children?:React.ReactNode}>=({cam,marks=[],rings=[],muted,children})=>{
 const [cx,cy]=merc(cam.lon,cam.lat);const s=cam.zoom/15;
 return <AbsoluteFill style={{overflow:'hidden',background:'#123a49'}}>
  <AbsoluteFill style={{transform:`perspective(2200px) rotateX(${cam.tilt??4}deg) scale(1.13)`,transformOrigin:'50% 47%'}}>
   <div style={{position:'absolute',left:540,top:900,transform:`rotate(${cam.rot??0}deg) scale(${s}) translate(${-cx}px,${-cy}px)`,transformOrigin:'0 0',width:5400,height:5400}}>
    <Img src={staticFile('maps/mercator-north.png')} style={{position:'absolute',left:0,top:-1600,width:5400,height:1601,display:'block',filter:`saturate(${muted?.65:1.18}) brightness(${muted?.58:.94}) contrast(1.12)`}}/>
    <Img src={staticFile('maps/mercator.jpg')} style={{width:5400,height:5400,display:'block',filter:`saturate(${muted?.65:1.18}) brightness(${muted?.58:.94}) contrast(1.12)`}}/>
    <svg width={5400} height={5400} style={{position:'absolute',inset:0,overflow:'visible'}}>
     <g opacity={.22} fill="none" stroke="#d7e5d0" strokeWidth={.8/s}>{geo.borders.map((p,i)=><path key={i} d={p.d??''}/>)}</g>
     {marks.map((m,i)=>{
      const r=geo.regions[m.id],p=m.labelAt??r.centroid;const [x,y]=merc(p[0],p[1]);const a=m.amount??1,alpha=m.opacity??1;
      return <g key={i} opacity={alpha}>
       <path d={r.d!} fill={m.color} fillOpacity={.39*a}/>
       <path d={r.d!} fill="none" stroke={m.color} strokeWidth={7/s} strokeLinejoin="round" opacity={.5} style={{filter:`drop-shadow(0 0 ${10/s}px ${m.color})`}}/>
       <path d={r.d!} fill="none" stroke={C.white} strokeWidth={2.8/s} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1-(m.draw??1)}/>
       {m.label&&<text x={x} y={y} fill={C.white} fontFamily="OpenSans" fontWeight={900} fontSize={(m.labelSize??57)/s} textAnchor="middle" stroke="#14282e99" strokeWidth={7/s} paintOrder="stroke" style={{filter:`drop-shadow(0 ${3/s}px ${5/s}px #00172a)`}}>{r.name}</text>}
      </g>;
     })}
     {rings.map((r,i)=>{const [x,y]=merc(r.lon,r.lat);return <ellipse key={`ring-${i}`} cx={x} cy={y} rx={r.rx} ry={r.ry} fill="none" stroke={r.color} strokeWidth={5/s} pathLength={1} strokeDasharray={1} strokeDashoffset={1-r.draw} style={{filter:`drop-shadow(0 0 ${6/s}px ${r.color})`}}/>;})}
    </svg>
   </div>
  </AbsoluteFill>
  <AbsoluteFill style={{background:'linear-gradient(180deg,#031b2d33 0%,transparent 24%,transparent 58%,#03172588 96%),radial-gradient(ellipse at 50% 40%,transparent 28%,#001b3355 100%)'}}/>
  {children}
 </AbsoluteFill>;
};
export const Word:React.FC<{x:number;y:number;children:React.ReactNode;size?:number;color?:string;delay?:number;rot?:number;align?:'left'|'center'|'right'}>=({x,y,children,size=64,color=C.white,delay=0,rot=0,align='center'})=>{
 const f=useCurrentFrame();return <div style={{position:'absolute',left:x,top:y,transform:`translate(-50%,-50%) rotate(${rot}deg) scale(${P(f,delay)})`,width:'max-content',maxWidth:920,fontFamily:'OpenSans',fontSize:size,fontWeight:900,color,lineHeight:1.06,textAlign:align,textShadow:`0 3px 0 #00142366,0 0 18px ${color}55,0 8px 18px #001423a0`,whiteSpace:'pre-line'}}>{children}</div>;
};
export const Figure:React.FC<{value:string;caption?:string;at?:number;y?:number;color?:string;size?:number}>=({value,caption,at=0,y=1430,color=C.yellow,size=142})=>{
 const f=useCurrentFrame();return <div style={{position:'absolute',left:80,top:y,width:920,textAlign:'center',fontFamily:'OpenSans',fontWeight:900,transform:`scale(${P(f,at)})`}}><div style={{fontSize:size,color,lineHeight:1,textShadow:`0 5px 0 #00192f,0 0 25px ${color}77,0 10px 25px #00192f`}}>{value}</div>{caption&&<div style={{fontSize:35,color:C.white,marginTop:15,textShadow:'0 3px 9px #001528'}}>{caption}</div>}</div>;
};
export const Cutout:React.FC<{id:Region;x:number;y:number;scale?:number;color:string;delay?:number;rotation?:number;opacity?:number;label?:boolean;reveal?:number}>=({id,x,y,scale=1,color,delay=0,rotation=0,opacity=1,label,reveal=1})=>{
 const f=useCurrentFrame();const r=geo.regions[id];const k=Math.sqrt(r.area)*scale*P(f,delay);const b=r.bounds;
 const w=b[1][0]-b[0][0],h=b[1][1]-b[0][1];
 return <><svg width={1080} height={1920} style={{position:'absolute',inset:0,overflow:'visible',opacity,filter:`drop-shadow(0 11px 10px #00152899) drop-shadow(0 0 9px ${color}66)`}}>
 <g transform={`translate(${x} ${y}) rotate(${rotation}) scale(${k})`}>
  <image href={staticFile(`territories/${id}.png`)} x={b[0][0]} y={b[0][1]} width={w} height={h}/>
  <path d={r.normalized!} fill={color} fillOpacity={.43}/><path d={r.normalized!} fill="none" stroke={color} strokeWidth={k>0?10/k:0} opacity={.65} strokeLinejoin="round"/><path d={r.normalized!} fill="none" stroke={C.white} strokeWidth={k>0?3.3/k:0} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1-reveal}/>
 </g></svg>{label&&<Word x={x} y={y+h*k/2+44} size={38} delay={delay+4} color={C.white}>{r.name}</Word>}</>;
};
export const Circle:React.FC<{x:number;y:number;rx:number;ry?:number;delay?:number;color?:string;rotation?:number}>=({x,y,rx,ry=rx,delay=0,color=C.yellow,rotation=-8})=>{
 const f=useCurrentFrame(),t=L(f,delay,delay+20);return <svg width={1080} height={1920} style={{position:'absolute',inset:0,pointerEvents:'none'}}><g transform={`translate(${x} ${y}) rotate(${rotation})`}><ellipse cx={0} cy={0} rx={rx} ry={ry} fill="none" stroke={color} strokeWidth={6} pathLength={1} strokeDasharray={1} strokeDashoffset={1-t}/><ellipse cx={-4} cy={4} rx={rx*1.03} ry={ry*.98} fill="none" stroke={color} strokeWidth={2.5} pathLength={1} strokeDasharray={1} strokeDashoffset={1-Math.max(0,(t-.25)/.75)} opacity={.6}/></g></svg>;
};
export const Trace:React.FC<{d:string;delay?:number;color?:string;width?:number}>=({d,delay=0,color=C.yellow,width=7})=>{const f=useCurrentFrame();return <svg width={1080} height={1920} style={{position:'absolute',inset:0,pointerEvents:'none'}}><path d={d} fill="none" stroke={color} strokeWidth={width} pathLength={1} strokeDasharray={1} strokeDashoffset={1-L(f,delay,delay+20)} strokeLinecap="round" strokeLinejoin="round" style={{filter:`drop-shadow(0 0 8px ${color})`}}/></svg>;};
export const Detail:React.FC<{children:React.ReactNode;y?:number}>=({children,y=1730})=><div style={{position:'absolute',left:95,top:y,width:890,fontFamily:'OpenSans',fontSize:25,fontWeight:800,color:'#e3edf0',textAlign:'center',lineHeight:1.3,textShadow:'0 2px 6px #001528'}}>{children}</div>;
export const Bracket:React.FC<{x:number;y:number;width:number;delay?:number}>=({x,y,width,delay=0})=><Trace delay={delay} color={C.yellow} d={`M${x} ${y-24} V${y} H${x+width} V${y-24}`}/>;
export {geo};
