import React from 'react';
import {Composition,Folder} from 'remotion';
import {MainV2,GlobalFonts} from './MainV2';
import {HookV2,GreenlandV2,RussiaV2,MexicoV2} from './SceneOpeningV2';
import {AfricaGreenlandV2,AfricaRussiaV2,EuropeMexicoV2} from './SceneComparisonsV2';
import {LeadV2,SumV2,SpaceV2} from './SceneSumV2';
import {ProjectionV2,EndingV2} from './SceneEndingV2';
export const RemotionRoot:React.FC=()=> <><GlobalFonts/>
<Composition id="CortoV2" component={MainV2} durationInFrames={1065} fps={30} width={1080} height={1920}/>
<Folder name="Escenas">
<Composition id="HookV2" component={HookV2} durationInFrames={150} fps={30} width={1080} height={1920}/>
<Composition id="GreenlandV2" component={GreenlandV2} durationInFrames={81} fps={30} width={1080} height={1920}/>
<Composition id="AfricaGreenlandV2" component={AfricaGreenlandV2} durationInFrames={95} fps={30} width={1080} height={1920}/>
<Composition id="RussiaV2" component={RussiaV2} durationInFrames={73} fps={30} width={1080} height={1920}/>
<Composition id="AfricaRussiaV2" component={AfricaRussiaV2} durationInFrames={70} fps={30} width={1080} height={1920}/>
<Composition id="MexicoV2" component={MexicoV2} durationInFrames={57} fps={30} width={1080} height={1920}/>
<Composition id="EuropeMexicoV2" component={EuropeMexicoV2} durationInFrames={132} fps={30} width={1080} height={1920}/>
<Composition id="LeadV2" component={LeadV2} durationInFrames={46} fps={30} width={1080} height={1920}/>
<Composition id="SumV2" component={SumV2} durationInFrames={126} fps={30} width={1080} height={1920}/>
<Composition id="SpaceV2" component={SpaceV2} durationInFrames={57} fps={30} width={1080} height={1920}/>
<Composition id="ProjectionV2" component={ProjectionV2} durationInFrames={85} fps={30} width={1080} height={1920}/>
<Composition id="EndingV2" component={EndingV2} durationInFrames={93} fps={30} width={1080} height={1920}/>
</Folder></>;
