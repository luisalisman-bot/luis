import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Atlas,camera,C,Word,Figure,Cutout,L,Detail,Bracket,Trace} from './MapV2';
export const AfricaGreenlandV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:12,lat:10,zoom:14,rot:-8,tilt:10},{at:19,lon:18,lat:5,zoom:17,rot:1,tilt:5},{at:94,lon:19,lat:4,zoom:18,rot:-2,tilt:5}]);
 return <><Atlas cam={cam} muted/>
 <Cutout id="africa" x={660} y={800} scale={.88+L(f,0,90,0,.025)} color={C.yellow} delay={3} label reveal={L(f,3,28)}/>
 <Cutout id="greenland" x={240} y={825} scale={.88+L(f,0,90,0,.025)} color={C.cyan} delay={9} label reveal={L(f,9,30)}/>
 <Word x={540} y={265} size={58} color={C.white} delay={7}>ESTA ES LA COMPARACIÓN REAL</Word>
 <Trace d="M255 590 Q170 650 225 700 M205 680 L225 700 238 675" delay={20}/>
 <Figure value="×14" caption="África es unas catorce veces más grande" at={33} y={1450} size={154}/>
 <Detail>30,37 frente a 2,17 millones de km² · misma escala de superficie</Detail>
 </>;
};
export const AfricaRussiaV2:React.FC=()=>{
 const f=useCurrentFrame();return <><Atlas cam={camera(f,[{at:0,lon:17,lat:5,zoom:15,rot:5,tilt:8},{at:69,lon:19,lat:4,zoom:18,rot:-3,tilt:5}])} muted/>
 <Cutout id="russia" x={300} y={750} scale={.56} color={C.red} delay={3} rotation={-9} label/>
 <Cutout id="africa" x={755} y={850} scale={.56} color={C.yellow} delay={8} label/>
 <Word x={540} y={300} size={77} color={C.white}>¿CASI EL DOBLE?</Word>
 <Figure value="1,8 ×" caption="África respecto a Rusia" at={17} y={1440} size={145}/><Detail>30,37 y 17,10 millones de km² · comparación por superficie</Detail>
 </>;
};
export const EuropeMexicoV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:0,lat:44,zoom:18,rot:8,tilt:9},{at:21,lon:-4,lat:40,zoom:45,rot:-5,tilt:6},{at:41,lon:2,lat:46.6,zoom:44,rot:2,tilt:4},{at:62,lon:10.2,lat:50.7,zoom:46,rot:-2,tilt:5},{at:82,lon:12.2,lat:42.5,zoom:43,rot:4,tilt:6},{at:99,lon:8,lat:43,zoom:23,rot:0,tilt:6},{at:117,lon:-102,lat:24,zoom:24,rot:-5,tilt:8},{at:131,lon:-102,lat:24,zoom:25.5,rot:0,tilt:5}]);
 const marks:any[]=[{id:'spain',color:C.yellow,label:f>=15&&f<40,draw:L(f,17,27),opacity:L(f,14,24)},{id:'france',color:C.cyan,label:f>=35&&f<61,draw:L(f,38,47),opacity:L(f,35,45)},{id:'germany',color:C.red,label:f>=56&&f<81,draw:L(f,59,68),opacity:L(f,56,65)},{id:'italy',color:C.purple,label:f>=77&&f<100,draw:L(f,80,90),opacity:L(f,77,86)},{id:'mexico',color:C.mint,label:f>=111,draw:L(f,109,123),opacity:L(f,105,117)}];
 return <><Atlas cam={cam} marks={marks}/>
 {f<100?<><Detail>España + Francia + Alemania + Italia</Detail></>:<>
 <Cutout id="spain" x={230} y={440} scale={1.05} color={C.yellow} delay={100}/><Cutout id="france" x={430} y={440} scale={1.05} color={C.cyan} delay={102}/><Cutout id="germany" x={640} y={440} scale={1.05} color={C.red} delay={104}/><Cutout id="italy" x={840} y={440} scale={1.05} color={C.purple} delay={106}/>
 <Bracket x={160} y={590} width={740} delay={103}/><Word x={540} y={650} size={38} delay={106}>LOS CUATRO JUNTOS</Word>
 <Figure value="1,96 > 1,72" caption="millones de km²" size={99} at={106} y={1450}/><Detail>Francia metropolitana · superficies aproximadas</Detail>
 </>}
 </>;
};
