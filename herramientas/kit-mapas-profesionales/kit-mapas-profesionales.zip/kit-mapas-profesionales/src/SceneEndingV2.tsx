import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Atlas,camera,C,Word,Figure,Cutout,L,Detail,Circle,Trace} from './MapV2';
export const ProjectionV2:React.FC=()=>{
 const f=useCurrentFrame();return <><Atlas cam={camera(f,[{at:0,lon:-42,lat:71.3,zoom:11.3,rot:-3,tilt:4},{at:35,lon:-40,lat:71.5,zoom:11.5,rot:1,tilt:4},{at:84,lon:-41,lat:71.3,zoom:11.7,rot:-2,tilt:4}])} marks={[{id:'greenland',color:C.red,label:true,labelAt:[-40,72],draw:L(f,0,20),labelSize:48}]} rings={[{lon:-40,lat:80,rx:480,ry:340,color:C.red,draw:L(f,12,32)}]}/>
 <Word x={540} y={215} size={61}>CERCA DE LOS POLOS...</Word>
 <Trace d="M200 390 L200 240 M175 270 L200 240 225 270 M830 445 L830 280 M805 310 L830 280 855 310" delay={28} color={C.red}/>
 <Word x={540} y={1490} size={67} color={C.yellow} delay={20}>EL ÁREA SE DEFORMA</Word><Detail>En una proyección de Mercator, las zonas polares se agrandan.</Detail>
 </>;
};
export const EndingV2:React.FC=()=>{
 const f=useCurrentFrame();return <><Atlas cam={camera(f,[{at:0,lon:-28,lat:31,zoom:6,rot:4,tilt:6},{at:25,lon:-28,lat:30,zoom:5.9,rot:0,tilt:4},{at:92,lon:-27,lat:28,zoom:6.2,rot:-3,tilt:4}])} marks={[{id:'africa',color:C.yellow,draw:L(f,0,20),amount:.4},{id:'mexico',color:C.mint,amount:.6,draw:L(f,8,26)},{id:'greenland',color:C.cyan,amount:.5,draw:L(f,14,33)}]}/>
 <Word x={540} y={270} size={78}>¿CUÁL TE<br/>SORPRENDIÓ MÁS?</Word>
 <Circle x={770} y={1060} rx={235} ry={330} delay={26}/><Word x={540} y={1510} size={77} color={C.yellow} delay={38}>COMENTA TU PAÍS</Word><Detail y={1640}>y te hago el siguiente</Detail>
 </>;
};
