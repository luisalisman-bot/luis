import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Atlas,camera,C,Word,Figure,Circle,L,Detail} from './MapV2';
export const HookV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:0,lat:34,zoom:10,rot:-9,tilt:10},{at:25,lon:-22,lat:53,zoom:13,rot:-5,tilt:8},{at:60,lon:-39,lat:65,zoom:20,rot:3,tilt:4},{at:100,lon:-40,lat:65,zoom:22,rot:-3,tilt:4},{at:149,lon:-37,lat:63,zoom:20,rot:0,tilt:5}]);
 return <><Atlas cam={cam} marks={[{id:'greenland',color:C.red,draw:L(f,3,35),amount:L(f,3,30),label:f>45,labelSize:48,labelAt:[-40,69]}]}/>
 {f<84?<><Word x={540} y={1430} size={f<22?91:114} color={f<22?C.white:C.red}>{f<22?'ESTE MAPA':'TE MIENTE'}</Word><Detail y={1600}>el tamaño que ves puede engañarte</Detail></>:<><Circle x={545} y={830} rx={265} ry={390} delay={84}/><Word x={540} y={1480} size={76} color={C.yellow} delay={87}>¿TAMAÑO REAL?</Word></>}
 </>;
};
export const GreenlandV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:-37,lat:63,zoom:20,rot:0,tilt:5},{at:22,lon:-42,lat:69,zoom:25,rot:-5,tilt:4},{at:58,lon:-40,lat:70,zoom:28,rot:2,tilt:3},{at:80,lon:-41,lat:69,zoom:26,rot:0,tilt:3}]);
 return <><Atlas cam={cam} marks={[{id:'greenland',color:C.cyan,label:true,labelAt:[-42,70],labelSize:53,draw:L(f,0,17)}]}/><Circle x={540} y={835} rx={310} ry={355} delay={35}/><Figure value="¿ENORME?" size={94} y={1450} at={34} color={C.white}/></>;
};
export const RussiaV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:75,lat:62,zoom:7.5,rot:9,tilt:10},{at:15,lon:90,lat:62,zoom:8.4,rot:3,tilt:8},{at:72,lon:106,lat:61,zoom:10.6,rot:-4,tilt:6}]);
 return <><Atlas cam={cam} marks={[{id:'russia',color:C.red,label:true,labelAt:[99,62],labelSize:85,draw:L(f,0,24)}]}/><Figure value="17,10" caption="millones de km² · el mayor país del mundo" size={133} y={1440} at={16} color={C.white}/></>;
};
export const MexicoV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:-100,lat:22,zoom:18,rot:12,tilt:10},{at:20,lon:-102,lat:24,zoom:27,rot:-5,tilt:5},{at:56,lon:-102,lat:24,zoom:28.5,rot:0,tilt:4}]);
 return <><Atlas cam={cam} marks={[{id:'mexico',color:C.mint,label:true,labelAt:[-102,24],labelSize:75,draw:L(f,0,20)}]}/><Figure value="1,96" caption="millones de km²" y={1450} size={135} at={17}/></>;
};
