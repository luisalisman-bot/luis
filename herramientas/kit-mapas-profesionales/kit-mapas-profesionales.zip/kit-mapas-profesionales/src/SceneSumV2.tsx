import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Atlas,camera,C,Word,Figure,Cutout,L,Detail,Circle,Trace} from './MapV2';
export const LeadV2:React.FC=()=>{const f=useCurrentFrame();return <><Atlas cam={camera(f,[{at:0,lon:-20,lat:25,zoom:10,rot:-8,tilt:10},{at:18,lon:18,lat:3,zoom:19,rot:3,tilt:5},{at:45,lon:18,lat:3,zoom:21,rot:-2,tilt:5}])} marks={[{id:'africa',color:C.yellow,draw:L(f,7,30),amount:.55}]}/><Circle x={540} y={850} rx={355} ry={590} delay={16}/><Word x={540} y={1500} size={93} color={C.yellow} delay={6}>LO MÁS LOCO...</Word></>;};
export const SumV2:React.FC=()=>{
 const f=useCurrentFrame();const cam=camera(f,[{at:0,lon:-105,lat:37,zoom:13,rot:-8,tilt:10},{at:20,lon:-100,lat:39,zoom:18,rot:0,tilt:5},{at:29,lon:104,lat:35,zoom:20,rot:4,tilt:7},{at:43,lon:103,lat:35,zoom:22,rot:0,tilt:4},{at:46,lon:80,lat:23,zoom:28,rot:-4,tilt:6},{at:58,lon:79,lat:22,zoom:30,rot:0,tilt:4},{at:74,lon:20,lat:2,zoom:17,rot:4,tilt:7},{at:125,lon:19,lat:3,zoom:19,rot:-2,tilt:5}]);
 const id=f<27?'usa':f<44?'china':f<59?'india':'africa';const color=f<27?C.cyan:f<44?C.red:f<59?C.yellow:C.mint;
 return <><Atlas cam={cam} muted={f>=64} marks={f<64?[{id,color,label:true,draw:L(f,f<27?0:f<44?27:44,f<27?12:f<44?37:55)}]:[]}/>
 {f<64?<></>:<>
 <Cutout id="africa" x={620} y={870} scale={.66} color={C.mint} delay={64} opacity={.42}/>
 <Cutout id="usa" x={430} y={680} scale={.66} color={C.cyan} delay={69} label/>
 <Cutout id="china" x={745} y={1050} scale={.66} color={C.red} delay={76} label/>
 <Cutout id="india" x={320} y={1090} scale={.66} color={C.yellow} delay={82} label/>
 <Word x={540} y={300} size={68} color={C.white} delay={66}>TRES GIGANTES SUMADOS</Word>
 <Figure value="22,72 < 30,37" caption="millones de km²" at={88} y={1450} size={93}/><Detail>Comparación de superficies; no es un encaje exacto de fronteras.</Detail>
 </>}
 </>;
};
export const SpaceV2:React.FC=()=>{
 const f=useCurrentFrame();return <><Atlas cam={camera(f,[{at:0,lon:18,lat:3,zoom:16,rot:4,tilt:8},{at:56,lon:19,lat:2,zoom:18,rot:-3,tilt:4}])} marks={[{id:'africa',color:C.mint,draw:L(f,0,20),amount:.7}]}/>
 <svg width={1080} height={1920} style={{position:'absolute',inset:0}}><g transform="translate(540 820) rotate(-90)"><circle r={375} fill="none" stroke="#ffffff44" strokeWidth={10}/><circle r={375} fill="none" stroke={C.yellow} strokeWidth={13} pathLength={1} strokeDasharray=".252 .748" strokeDashoffset={L(f,0,25,.252,0)} strokeLinecap="round" style={{filter:'drop-shadow(0 0 14px #ffe253)'}}/></g></svg>
 <Word x={540} y={840} size={135} color={C.yellow} delay={7}>25 %</Word><Word x={540} y={965} size={46} delay={12}>TODAVÍA LIBRE</Word>
 <Figure value="+7,65" caption="millones de km² de espacio restante" at={12} y={1450} size={141}/>
 </>;
};
