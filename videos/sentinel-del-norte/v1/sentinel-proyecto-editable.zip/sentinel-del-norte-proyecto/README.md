# Sentinel del Norte — proyecto editable
Edición vertical terminada con la voz original proporcionada por el usuario.

## Reproducir la edición
1. Instala Node.js 18+, Python 3 y FFmpeg, y ejecuta `npm ci`.
2. Coloca el MP3 original en `public/audio.mp3`. No se distribuye su copia original dentro del ZIP público.
3. Previsualiza: `npx remotion studio --no-open` y abre la dirección que indique.
4. Exporta: `npx remotion render src/index.ts Sentinel out/sentinel-raw.mp4 --concurrency=2 --video-bitrate=6M`. En este entorno usamos `--browser-executable=/usr/bin/chromium`; en otro equipo Remotion puede usar su navegador administrado.
5. `python scripts/finish.py` normaliza el audio de la exportación a −16 LUFS / pico verdadero máximo −1,5 dBTP, conserva el video y prepara el MP4 final.
6. Valida la entrega exacta: `python scripts/validate_video.py out/sentinel-del-norte.mp4 76.3`.
7. Miniatura: `npx remotion still src/index.ts Miniatura out/miniatura-sentinel-3x4.png`.

Los subtítulos y recursos visuales/sonoros ya están preparados. Los scripts de ASR y alineación conservan las rutas del entorno de producción como referencia, por lo que requieren adaptar las dependencias locales para volver a transcribir; no son necesarios para reproducir esta edición. Si cambias la voz o el guion, actualiza primero la alineación, la duración y las escenas. El archivo original no se estira para alcanzar noventa segundos.

Lee STYLE.md y SOURCES.md para mantener el estilo, las fuentes y la identificación de recreaciones. Los cambios nuevos deben revisarse antes de volver a publicar. Consulta los archivos de evidencia para la revisión de esta versión.
