# Revisión de producción
- Voz original de 76,2775 s preservada en contenido y ritmo.
- ASR CTC local: 98,4 % de caracteres coincidentes con el guion; nombres corregidos y años confirmados con Whisper tiny local.
- TypeScript sin errores antes de exportar.
- Muestra real de helicóptero de 210 cuadros (7 s) renderizada a media escala y revisada como secuencia.
- 22 fotogramas clave revisados: mapas, límite de 5 km, ubicación, leyendas, años, recreaciones y subtítulos.
- Ajuste del microorganismo principal para centrar el foco visual y simplificación de la leyenda conceptual.
- Miniatura revisada en formato exacto 1080×1440 (3:4).
- Revisión de la exportación a 2 cuadros por segundo: 153 imágenes de todo el metraje distribuidas en cuatro hojas de contacto. Las celdas negras finales son relleno de la última hoja, no pertenecen al video.
- Archivo final: 76,300 s, 2289 cuadros, 1080×1920, H.264/AAC. Decodificación completa y átomos MP4 correctos; ningún intervalo negro detectado.
- Mezcla final medida en el AAC: −16,1 LUFS integrados y −2,1 dBFS de pico verdadero. Se dejó margen adicional en la normalización para compensar los picos del codificador AAC.
- SHA256 del archivo final: 5cfea14a85e737e823b1b034e2618a489ce5ceb87e52e5684f47d29e3ae6be8a

