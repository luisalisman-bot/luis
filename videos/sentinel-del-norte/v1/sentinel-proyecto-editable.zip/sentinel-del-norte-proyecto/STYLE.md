# Sentinel del Norte — continuidad visual
Base aprobada: mapas satelitales a pantalla completa, movimientos geográficos claros, colores marinos, límites luminosos y tipografía Open Sans blanca con cifras amarillas. Montaje vertical 1080×1920, 30 fps, duración 76,3 segundos (audio original 76,2775).
17 escenas con encuadres, fechas, movimiento de cámara y efectos motivados. No alargar la voz para alcanzar 90 segundos.
Los planos ilustrados son recreaciones y llevan esa identificación. La ilustración cartográfica usa contorno Natural Earth de 10 m y textura satelital de Sentinel; no se presenta como fotografía georreferenciada completa. El plano satelital usa una imagen real NASA EO-1 ALI, recortada en la fuente pública. El perímetro rojo representa la reserva a 5 km de la costa mediante banda métrica de contorno.
La amenaza sanitaria se representa conceptualmente y no implica un brote documentado.
Se preserva la grabación; música y 33 efectos originales sintetizados localmente, con ducking de diálogo. Subtítulos de 2–3 palabras alineados con ASR CTC local y verificación de fechas con Whisper tiny local.
