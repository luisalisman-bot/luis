import json,re,unicodedata,difflib
from pathlib import Path
import numpy as np
r=Path(__file__).resolve().parent.parent;d=json.loads((r/'ctc.json').read_text())
def norm(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower()) if unicodedata.category(c)!='Mn' and (c.isalnum() or c.isspace()))
spoken='';times=[]
for i,(tok,t) in enumerate(zip(d['tokens'],d['timestamps'])):
 s=norm(tok);end=d['timestamps'][i+1] if i+1<len(d['timestamps']) else 75.9
 for j,c in enumerate(s):spoken+=c;times.append(t+(end-t)*j/max(1,len(s)))
target='';ranges=[]
for w in (r/'SCRIPT.txt').read_text().split():
 if target:target+=' '
 a=len(target);target+=norm(w);ranges.append((a,len(target),w))
known={}
for a,b,n in difflib.SequenceMatcher(None,target,spoken,autojunk=False).get_matching_blocks():
 for j in range(n):known[a+j]=times[b+j]
xs=sorted(known);tt=np.interp(np.arange(len(target)),xs,[known[i] for i in xs]);words=[]
for a,b,w in ranges:words.append({'text':' '+w,'startMs':round(tt[a]*1000),'endMs':round((tt[b-1]+.07)*1000),'timestampMs':round(tt[a]*1000),'confidence':None})
# Independent Whisper checks confirm these dates, omitted by the CTC model.
for i,w in enumerate(words):
 if '2004' in w['text']:w['startMs']=27770;w['endMs']=28250
 if '1991' in w['text']:w['startMs']=45600;w['endMs']=46200
for i,w in enumerate(words):
 if i+1<len(words):w['endMs']=min(max(w['endMs'],w['startMs']+45),words[i+1]['startMs'])
 w['endMs']=max(w['startMs']+35,w['endMs'])
(r/'public/captions.json').write_text(json.dumps(words,ensure_ascii=False,indent=2))
phrases=[];group=[]
for i,w in enumerate(words):
 group.append(w)
 if len(group)>=3 or re.search(r'[.,!?;:…]$',w['text']) or i==len(words)-1:
  phrases.append({'text':' '.join(x['text'].strip() for x in group),'start':group[0]['startMs']/1000,'end':group[-1]['endMs']/1000});group=[]
(r/'src/phrases.json').write_text(json.dumps(phrases,ensure_ascii=False,indent=2))
def stamp(t):
 m=round(t*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'
srt=[]
for i,p in enumerate(phrases):srt.append(f'{i+1}\n{stamp(p["start"])} --> {stamp(p["end"])}\n{p["text"]}\n')
(r/'out/sentinel-del-norte.srt').write_text('\n'.join(srt))
print('Aligned',len(words),'words;',round(len(known)/len(target)*100,1),'percent character matches')
for p in phrases:print(round(p['start'],2),round(p['end'],2),p['text'])
