from pathlib import Path
import numpy as np
from scipy import signal
import wave,json,subprocess
r=Path(__file__).resolve().parent.parent;sr=48000;duration=76.3;n=round(duration*sr);t=np.arange(n)/sr;rng=np.random.default_rng(7221)
# Original score: restrained drone, quiet mallets, water and event-led effects.
music=np.zeros(n);pad=(np.sin(2*np.pi*73.416*t)+.48*np.sin(2*np.pi*110*t)+.24*np.sin(2*np.pi*146.832*t))*.0034
pad*=.8+.2*np.sin(t*.7);music+=pad
for beat in np.arange(0,76,1.5):
 j=round(beat*sr);tt=np.arange(min(round(1.3*sr),n-j))/sr;freq=[293.665,220,261.626,195.998][int(beat/1.5)%4];s=(np.sin(2*np.pi*freq*tt)+.24*np.sin(2*np.pi*freq*2.01*tt))*np.exp(-tt*4)*np.minimum(1,tt/.009)*.005
 music[j:j+len(s)]+=s
# Genuine pause in the score at the question; let the narrator carry the turn.
music*=np.where((t>50.85)&(t<53.43),.05,1)
noise=rng.normal(0,1,n);sea=signal.sosfilt(signal.butter(2,[110,1500],btype='bandpass',fs=sr,output='sos'),noise)*(.002+.0015*np.sin(t*.55)**2)
base=music+sea;mix=np.column_stack([base,base]);events=[]
def add(at,kind,gain=.05,pan=0,length=None):
 length=length or {'fly':.48,'tap':.1,'impact':.62,'shutter':.15,'plop':.35,'arrow':.18,'rotor':6.5,'scan':.5}.get(kind,.5);tt=np.arange(round(length*sr))/sr;z=rng.normal(0,1,len(tt));env=np.sin(np.pi*tt/length)**2
 if kind=='fly':s=signal.sosfilt(signal.butter(3,[250,4500],btype='bandpass',fs=sr,output='sos'),z)*env
 elif kind=='impact':s=(np.sin(2*np.pi*(85*tt-35*tt*tt/length))+.2*np.sin(2*np.pi*170*tt))*np.exp(-tt*8)*np.minimum(1,tt/.012)
 elif kind=='tap':s=np.sin(2*np.pi*870*tt)*np.exp(-tt*65)
 elif kind=='shutter':s=signal.sosfilt(signal.butter(2,[1500,6000],btype='bandpass',fs=sr,output='sos'),z)*np.exp(-tt*35)
 elif kind=='plop':s=np.sin(2*np.pi*(420*tt-240*tt*tt/length))*np.exp(-tt*14)*np.minimum(1,tt/.01)
 elif kind=='arrow':s=signal.sosfilt(signal.butter(2,[1100,8000],btype='bandpass',fs=sr,output='sos'),z)*env
 elif kind=='rotor':s=(signal.sosfilt(signal.butter(2,[70,850],btype='bandpass',fs=sr,output='sos'),z)*.5+np.sin(2*np.pi*70*tt)*.15)*(np.maximum(0,np.sin(2*np.pi*17*tt))**3+.1)*np.minimum(1,tt/.9)*np.minimum(1,(length-tt)/1)
 else:s=signal.chirp(tt,300,length,1700)*env*.4
 s=s/(np.max(np.abs(s))+1e-12);i=round(at*sr);m=min(len(s),n-i);mix[i:i+m,0]+=s[:m]*gain*np.sqrt((1-pan)/2);mix[i:i+m,1]+=s[:m]*gain*np.sqrt((1+pan)/2);events.append({'at':at,'type':kind,'gain':gain,'pan':pan,'duration':length})
for args in [(0,'impact',.075,0),(1.7,'fly',.04,.3),(3.5,'impact',.045,0),(6.48,'fly',.055,-.3),(8.7,'scan',.025,0),(11.1,'fly',.045,.2),(13.02,'fly',.055,0),(15.32,'impact',.05,0),(17.52,'fly',.04,-.2),(22,'scan',.025,0),(26.27,'impact',.045,0),(28.37,'rotor',.038,-.25),(31.63,'shutter',.035,0),(32.0,'arrow',.045,.35),(32.75,'arrow',.035,.1),(33.48,'arrow',.035,-.2),(35.36,'fly',.055,.3),(36.1,'tap',.045,0),(38.23,'fly',.04,-.2),(42.16,'impact',.045,0),(43.18,'fly',.045,.3),(45.57,'tap',.045,0),(49.44,'plop',.045,-.15),(50.89,'fly',.035,0),(53.43,'impact',.065,0),(55.1,'scan',.035,0),(56.56,'fly',.045,-.15),(60.05,'impact',.035,0),(62.48,'fly',.055,.2),(64.3,'tap',.035,0),(67.2,'fly',.04,-.2),(71.92,'scan',.025,0),(74.21,'fly',.04,.2)]:add(*args)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(r/'public/audio.mp3'),'-f','f32le','-ar',str(sr),'-ac','1','-']);vo=np.frombuffer(raw,np.float32);v=np.zeros(n);v[:min(n,len(vo))]=vo[:n];rms=np.sqrt(signal.convolve(v*v,np.ones(2400)/2400,mode='same',method='fft'));mix*= (1-.35*np.clip((rms-.012)/.08,0,1))[:,None];mix[:2400]*=np.linspace(0,1,2400)[:,None];mix[-12000:]*=np.linspace(1,0,12000)[:,None]
with wave.open(str(r/'public/soundtrack.wav'),'wb') as out:out.setnchannels(2);out.setsampwidth(2);out.setframerate(sr);out.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
(r/'scripts/SOUND_CUES.json').write_text(json.dumps(events,indent=2));print(len(events),'synchronized cues, original soundtrack, dialogue ducking')
