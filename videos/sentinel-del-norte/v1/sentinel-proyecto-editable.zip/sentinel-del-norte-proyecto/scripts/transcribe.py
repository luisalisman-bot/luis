import sys,json,wave
from pathlib import Path
sys.path.insert(0,'/workspace/video-bebe/tools')
import sherpa_onnx,numpy as np
from scipy.signal import resample_poly
root=Path('/workspace/work/sentinel-norte');m=Path('/workspace/video-bebe/tools/sherpa-onnx-nemo-fast-conformer-ctc-es-1424-int8')
r=sherpa_onnx.OfflineRecognizer.from_nemo_ctc(model=str(m/'model.int8.onnx'),tokens=str(m/'tokens.txt'),num_threads=4)
with wave.open(str(root/'public/voice16.wav')) as f:a=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
s=r.create_stream();s.accept_waveform(16000,a);r.decode_stream(s)
o={'text':s.result.text,'tokens':s.result.tokens,'timestamps':s.result.timestamps,'durations':s.result.durations}
print(json.dumps(o,ensure_ascii=False),flush=True)
(root/'ctc.json').write_text(json.dumps(o,ensure_ascii=False,indent=2))
