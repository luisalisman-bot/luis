import sys,json,subprocess,hashlib,struct
from pathlib import Path
p=Path(sys.argv[1]);expected=float(sys.argv[2])
run=lambda args:subprocess.run(args,capture_output=True,text=True,check=True)
meta=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]).stdout)
v=next(s for s in meta['streams']if s['codec_type']=='video');a=next(s for s in meta['streams']if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1080,1920)
assert abs(float(meta['format']['duration'])-expected)<.10
assert int(v['nb_read_frames'])==2289
atoms=[]
with p.open('rb')as f:
 while True:
  h=f.read(8)
  if not h:break
  assert len(h)==8
  size,typ=struct.unpack('>I4s',h);header=8
  if size==1:size=struct.unpack('>Q',f.read(8))[0];header=16
  if size==0:size=p.stat().st_size-f.tell()+header
  assert size>=header
  atoms.append(typ.decode());f.seek(size-header,1)
 assert f.tell()==p.stat().st_size
assert all(x in atoms for x in ['ftyp','moov','mdat'])
decoded=run(['ffmpeg','-hide_banner','-loglevel','info','-xerror','-i',str(p),'-vf','blackdetect=d=0.05:pix_th=0.02','-f','null','-'])
assert 'black_start:' not in decoded.stderr, 'Black interval detected'
analysis=run(['ffmpeg','-hide_banner','-i',str(p),'-vn','-af','ebur128=peak=true','-f','null','-']).stderr
result={'path':str(p),'bytes':p.stat().st_size,'duration':meta['format']['duration'],'frames':v['nb_read_frames'],'dimensions':[v['width'],v['height']],'atoms':atoms,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'decode':'all frames and audio decoded','black_intervals':False,'audio_analysis':analysis[analysis.rfind('Summary:'):]}
print(json.dumps(result,indent=2,ensure_ascii=False))
