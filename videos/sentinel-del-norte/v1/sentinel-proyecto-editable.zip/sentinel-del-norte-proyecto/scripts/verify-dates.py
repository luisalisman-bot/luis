import sys,json,wave
sys.path.insert(0,'/workspace/video-bebe/tools')
import sherpa_onnx,numpy as np
from scipy.signal import resample_poly
from pathlib import Path
root=Path('/workspace/work/sentinel-norte')
m=Path('/workspace/video-bebe/tools/sherpa-onnx-whisper-tiny')
r=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(m/'tiny-encoder.int8.onnx'),decoder=str(m/'tiny-decoder.int8.onnx'),tokens=str(m/'tiny-tokens.txt'),language='es',num_threads=4,enable_token_timestamps=True,enable_segment_timestamps=True)
with wave.open(str(root/'public/voice16.wav')) as f:
 a=np.frombuffer(f.readframes(f.getnframes()),dtype=np.int16).astype(np.float32)/32768
 a=a
out=[]
for start,end in [(26,29),(44,49)]:
 s=r.create_stream();s.accept_waveform(16000,a[int(start*16000):int(end*16000)])
 r.decode_stream(s)
 print('RESULT',dir(s.result), str(s.result),flush=True)
 o={'start':start,'end':end,'text':s.result.text,'tokens':s.result.tokens,'timestamps':s.result.timestamps,'durations':s.result.durations}
 print(json.dumps(o,ensure_ascii=False),flush=True);out.append(o)
(root/'debug-transcript.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
