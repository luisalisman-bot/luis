import React from 'react';import {AbsoluteFill,Audio,Series,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Fonts} from './Visuals';import phrases from './phrases.json';
import {Opening,Locator,Paradise,Reserve} from './SceneOpening';import {Isolation,Unknown,Tsunami} from './SceneIsolation';import {HelicopterScene,ChauScene,PeaceScene} from './SceneEncounters';import {QuestionScene,InvisibleScene,DiseaseScene,ProtectionScene,BeachScene,FinalQuestion,LoopScene} from './SceneProtection';
export const Captions=()=>{const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;const p=phrases.find((p,i)=>t>=p.start&&t<Math.min(p.end+.09,phrases[i+1]?.start??100));return p?<div style={{position:'absolute',top:1435,left:90,right:90,textAlign:'center',fontSize:47,lineHeight:1.2,color:'white',fontWeight:750,textShadow:'0 3px 5px #00151e,0 0 20px #00151e,0 0 8px #00151e'}}>{p.text.replace(/[¡¿]/g,'').replace(/[.!?…,:;]+$/,'')}</div>:null};
export const Main=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{fontFamily:'OpenSans',background:'#062a38',overflow:'hidden'}}><Fonts/><Series>
 <Series.Sequence name="Gancho: el doble peligro" durationInFrames={195} premountFor={fps}><Opening/></Series.Sequence>
 <Series.Sequence name="India y Sentinel del Norte" durationInFrames={138} premountFor={fps}><Locator/></Series.Sequence>
 <Series.Sequence name="La isla desde el satélite" durationInFrames={57} premountFor={fps}><Paradise/></Series.Sequence>
 <Series.Sequence name="Reserva: cinco kilómetros desde la costa" durationInFrames={135} premountFor={fps}><Reserve/></Series.Sequence>
 <Series.Sequence name="Los sentinelenses y el aislamiento" durationInFrames={135} premountFor={fps}><Isolation/></Series.Sequence>
 <Series.Sequence name="Cómo se llaman a sí mismos" durationInFrames={128} premountFor={fps}><Unknown/></Series.Sequence>
 <Series.Sequence name="Tsunami de 2004" durationInFrames={63} premountFor={fps}><Tsunami/></Series.Sequence>
 <Series.Sequence name="Helicóptero: recreación ilustrada" durationInFrames={210} premountFor={fps}><HelicopterScene/></Series.Sequence>
 <Series.Sequence name="John Allen Chau: 2018" durationInFrames={234} premountFor={fps}><ChauScene/></Series.Sequence>
 <Series.Sequence name="Encuentros pacíficos: 1991" durationInFrames={232} premountFor={fps}><PeaceScene/></Series.Sequence>
 <Series.Sequence name="Por qué mantener la distancia" durationInFrames={76} premountFor={fps}><QuestionScene/></Series.Sequence>
 <Series.Sequence name="El peligro invisible" durationInFrames={94} premountFor={fps}><InvisibleScene/></Series.Sequence>
 <Series.Sequence name="Riesgo de introducir enfermedades" durationInFrames={177} premountFor={fps}><DiseaseScene/></Series.Sequence>
 <Series.Sequence name="Protección y rechazo al contacto" durationInFrames={142} premountFor={fps}><ProtectionScene/></Series.Sequence>
 <Series.Sequence name="El límite de la playa" durationInFrames={142} premountFor={fps}><BeachScene/></Series.Sequence>
 <Series.Sequence name="Quién necesita protección" durationInFrames={68} premountFor={fps}><FinalQuestion/></Series.Sequence>
 <Series.Sequence name="Regreso al encuadre inicial" durationInFrames={63} premountFor={fps}><LoopScene/></Series.Sequence>
 </Series><Captions/><Audio src={staticFile('audio.mp3')} volume={1}/><Audio src={staticFile('soundtrack.wav')} volume={1}/></AbsoluteFill>};
