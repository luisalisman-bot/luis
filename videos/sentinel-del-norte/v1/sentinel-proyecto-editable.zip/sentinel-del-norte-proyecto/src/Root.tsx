import React from 'react';import {Composition,Still,Folder} from 'remotion';import {Main} from './Main';import {Thumbnail} from './Thumbnail';import {Opening,Locator,Paradise,Reserve} from './SceneOpening';import {Isolation,Unknown,Tsunami} from './SceneIsolation';import {HelicopterScene,ChauScene,PeaceScene} from './SceneEncounters';import {QuestionScene,InvisibleScene,DiseaseScene,ProtectionScene,BeachScene,FinalQuestion,LoopScene} from './SceneProtection';
export const RemotionRoot=()=> <><Composition id="Sentinel" component={Main} durationInFrames={2289} fps={30} width={1080} height={1920}/><Still id="Miniatura" component={Thumbnail} width={1080} height={1440}/><Folder name="Escenas">
<Composition id="Gancho" component={Opening} durationInFrames={195} fps={30} width={1080} height={1920}/>
<Composition id="Ubicacion" component={Locator} durationInFrames={138} fps={30} width={1080} height={1920}/>
<Composition id="Satelite" component={Paradise} durationInFrames={57} fps={30} width={1080} height={1920}/>
<Composition id="Reserva" component={Reserve} durationInFrames={135} fps={30} width={1080} height={1920}/>
<Composition id="Aislamiento" component={Isolation} durationInFrames={135} fps={30} width={1080} height={1920}/>
<Composition id="Nombre" component={Unknown} durationInFrames={128} fps={30} width={1080} height={1920}/>
<Composition id="Tsunami" component={Tsunami} durationInFrames={63} fps={30} width={1080} height={1920}/>
<Composition id="Helicoptero" component={HelicopterScene} durationInFrames={210} fps={30} width={1080} height={1920}/>
<Composition id="Chau2018" component={ChauScene} durationInFrames={234} fps={30} width={1080} height={1920}/>
<Composition id="Encuentros1991" component={PeaceScene} durationInFrames={232} fps={30} width={1080} height={1920}/>
<Composition id="Pregunta" component={QuestionScene} durationInFrames={76} fps={30} width={1080} height={1920}/>
<Composition id="Infeccion" component={InvisibleScene} durationInFrames={94} fps={30} width={1080} height={1920}/>
<Composition id="Enfermedades" component={DiseaseScene} durationInFrames={177} fps={30} width={1080} height={1920}/>
<Composition id="Proteccion" component={ProtectionScene} durationInFrames={142} fps={30} width={1080} height={1920}/>
<Composition id="Playa" component={BeachScene} durationInFrames={142} fps={30} width={1080} height={1920}/>
<Composition id="PreguntaFinal" component={FinalQuestion} durationInFrames={68} fps={30} width={1080} height={1920}/>
<Composition id="Cierre" component={LoopScene} durationInFrames={63} fps={30} width={1080} height={1920}/>
</Folder></>;
