# Continuar esta producción
Lee README.md, STYLE.md, SOURCES.md, SCRIPT.txt, SHOT_LOG.csv y project.json antes de modificar el montaje. El video principal es SentinelV2 y la miniatura es MiniaturaV2, registrados en src/Root.tsx. El montaje original usa el MP3 del usuario, dura 76,3 s y contiene 17 escenas.

Mantén mapas legibles a pantalla completa, zooms y desplazamientos con sentido geográfico, recreaciones documentadas como tales fuera del encuadre, comparaciones y datos verificables, y subtítulos dentro del área segura. Conservar una voz significa mantener su contenido, interpretación y ritmo; no alargues el audio para llegar a una duración redonda.

No presentes las ilustraciones como registros históricos ni las texturas de la cartografía ilustrada como una foto satelital georreferenciada. La foto satelital real está acreditada a NASA. Para Sentinel del Norte, respeta el contexto de protección y su rechazo al contacto, y evita la afirmación falsa de que todos los visitantes mueren.

Al modificar guion o voz, alinea los subtítulos de nuevo y adapta escenas y duración. Los subtítulos ya preparados permiten reproducir esta versión sin modelos de ASR. Revisa una muestra en movimiento antes de una exportación larga y revisa hojas de contacto del video final. Mide el audio terminado y decodifica todos los fotogramas del archivo exacto que se entregue. Publica solo dentro del alcance autorizado por el usuario.

Las preferencias actuales están en STYLE.md: V1 fue rechazada. No vuelvas a introducir encabezados o créditos dentro del encuadre. Consulta REVIEW_V2.md para los fallos corregidos y los pendientes.
