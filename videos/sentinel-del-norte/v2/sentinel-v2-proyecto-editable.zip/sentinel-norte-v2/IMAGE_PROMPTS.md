# Recursos de imagen V2
Todos los recursos generados son recreaciones editoriales. No son fotografías históricas ni documentan la apariencia exacta de una persona, helicóptero histórico o tramo de playa.

## objects-v2.png
Atlas cuadrado transparente con cuatro celdas iguales y margen. Arriba izquierda: helicóptero genérico de rescate, perfil hacia la derecha, marfil y naranja, materiales realistas, fuselaje sin aspas para animarlas aparte. Arriba derecha: canoa de madera vacía vista desde arriba, proa hacia arriba. Abajo izquierda: un coco entero con fibras y tres poros. Abajo derecha: corona de salpicadura de agua turquesa. Sin letras, fondos ni bordes. Se emplean recortes CSS de las celdas sin modificar el original y se animan como capas independientes.

## coast-v2.png
Fondo aéreo vertical de una costa tropical remota del golfo de Bengala, vista oblicua desde dron. Agua turquesa/verde azulado a la izquierda, playa estrecha clara y selva densa a la derecha, detalle natural de arrecife y pequeñas olas, luz cálida. Sin personas, barcos, edificios, animales, flechas ni letras. Debe tener suficiente agua vacía para animar la canoa y los cocos. Recreación ilustrada de alta definición con acabado cinematográfico.

## reconstructions.png
Cuatro fondos anteriores conservados como recursos complementarios: playa vista desde el mar, costa cenital con canoa (no utilizada como fondo de canoa en V2), cocos junto a bote (no utilizada para la animación independiente), playa al amanecer. V2 usa principalmente las celdas de playa y amanecer; los objetos y la costa de la acción tienen recursos nuevos.
