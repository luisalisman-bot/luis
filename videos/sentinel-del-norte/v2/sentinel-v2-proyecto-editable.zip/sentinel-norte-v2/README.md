# Sentinel del Norte — V2 editable
Reconstrucción solicitada por el usuario: sin encabezados ni créditos dentro del encuadre, con nueva cámara, objetos independientes, captions Anton y mezcla sonora rehecha. V1 se conserva como antecedente; no es la edición aprobada.

## Reproducir esta edición
1. Instala Node.js 18+, Python 3 y FFmpeg; ejecuta `npm ci`.
2. Coloca el MP3 original del usuario en `public/audio.mp3`. Su hash esperado está en `project.json`. El ZIP público excluye la copia original de la voz.
3. Previsualiza con `npx remotion studio --no-open` y selecciona `SentinelV2`.
4. Exporta con `npx remotion render src/index.ts SentinelV2 out/sentinel-v2-raw.mp4 --concurrency=2 --video-bitrate=6M`. En el entorno de producción se añadió `--browser-executable=/usr/bin/chromium`; en otro equipo usa el navegador administrado de Remotion.
5. Ejecuta `python scripts/finish.py`: copia el video y normaliza la mezcla con margen de codificación AAC para un resultado aproximado de −16 LUFS y pico verdadero máximo −1,5 dBFS.
6. Valida el archivo terminado: `python scripts/validate_video.py out/sentinel-del-norte-v2.mp4 76.3`.
7. Miniatura: `npx remotion still src/index.ts MiniaturaV2 out/miniatura-sentinel-v2-3x4.png`.

Los mapas, ilustraciones, atlas de objetos, fuentes locales, 65 páginas de captions y banda sonora están incluidos. La voz dura 76,2775 s y se conserva sin cambiar texto, interpretación ni ritmo. El montaje ocupa 2289 cuadros a 30 fps (76,3 s).

## Cambios de guion o voz
Adapta primero escenas, subtítulos y duración. La transcripción/alineación de la grabación se hizo localmente y los scripts ASR conservan rutas del entorno original: requieren adaptar modelos y dependencias para volver a transcribir. No son necesarios para reproducir esta versión. `scripts/captions-v2.py` crea los grupos semánticos desde los tiempos de palabra preparados. Las fechas se escriben numéricamente en los subtítulos.

Lee STYLE.md, REVIEW_V2.md, AGENTS.md, SOURCES.md y los cues de sonido antes de editar. No reinstales los encabezados y créditos del encuadre que el usuario rechazó. Las recreaciones y fuentes se identifican en la documentación y descripción externa; no son registros históricos.

La geometría preparada está en src/geography.json. Si necesitas regenerarla desde la fuente pública: `python scripts/fetch-geography.py` y después `node scripts/prepare-geo.mjs`. No hace falta descargarla para renderizar esta versión.
