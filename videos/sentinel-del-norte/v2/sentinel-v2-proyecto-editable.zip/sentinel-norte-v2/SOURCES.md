# Fuentes y derechos
- Protección oficial, reserva que incluye 5 km de mar desde la pleamar: https://www.pib.gov.in/PressReleaseIframePage.aspx?PRID=1562728&lang=2&reg=48
- Sentinelenses, encuentros de 1991, helicóptero tras tsunami 2004, John Allen Chau 2018 y riesgo de enfermedades: https://www.survivalinternational.org/peoples/sentinelese
- Natural Earth, contorno de la isla y países: dominio público. https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_10m_admin_0_countries.geojson
- NASA Blue Marble: recursos geográficos ya empleados en la edición V2 aprobada.
- Foto satelital NASA Earth Observatory, EO-1 ALI, dominio público, copia recortada obtenida de https://github.com/vsingh2110/vikas-singh-nextjs/blob/main/public/images/blogs-images/last-free-humans-north-sentinel/10-north-sentinel-island-no-contact-1600x900.jpg ; atribución en https://github.com/vsingh2110/vikas-singh-nextjs/blob/main/content/blog/en/last-free-humans-north-sentinel-island.mdx (sección Image credits). No se usan las demás fotografías del blog.
- Cuatro recreaciones ilustradas: generadas para este montaje; no son archivos históricos ni fotografías de los sentinelenses.
- Open Sans: licencia OFL incluida en public/fonts.
- Voz: grabación original proporcionada por el usuario. No regenerada ni enviada a servicios externos para transcribir.
- Archivo candidato sentinel-full.jpg descartado porque mostraba una isla genérica y no había procedencia suficiente para identificarlo como Sentinel. No se emplea ni se redistribuye.

## Recursos nuevos de V2
- Anton, Vernon Adams / Google Fonts, SIL Open Font License: archivo y licencia locales en public/fonts/Anton.ttf y Anton-OFL.txt. Fuente: https://github.com/google/fonts/tree/main/ofl/anton
- public/objects-v2.png: atlas transparente generado para esta edición con helicóptero genérico de rescate (sin aspas, animadas aparte), canoa vacía, coco y salpicadura. Recreaciones ilustradas; no identifica un modelo exacto ni una persona histórica.
- public/coast-v2.png: recreación aérea de una costa tropical, generada para mostrar acción y movimiento con mayor definición. No es una fotografía de archivo de Sentinel ni se usa para medir distancias. Los mapas de ubicación y el esquema de cinco kilómetros usan cartografía geográfica real.
- scripts/sound-design-v2.py / SOUND_CUES_V2.json: música y efectos originales sintetizados localmente para los eventos del mismo cuadro. No se reutiliza el diseño sonoro de otros creadores.
