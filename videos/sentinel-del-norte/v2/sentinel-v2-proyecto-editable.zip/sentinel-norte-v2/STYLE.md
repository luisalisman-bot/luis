# Preferencias actuales del usuario — Sentinel V2
El usuario rechazó V1 por genérica, con encabezados y créditos dentro del encuadre, cámara poco activa, sonidos poco perceptibles y captions pequeños. Esa versión es un antecedente rechazado, no una base aprobada.

V2 conserva la narración original (76,2775 s). La exportación dura 76,3 s, 1080×1920, 30 fps. El video principal es SentinelV2.

- Sin encabezados de sección, rótulos editoriales permanentes, coordenadas ni créditos de fuentes en pantalla. Las fuentes y la identificación de recreaciones se documentan fuera del video.
- Solo captions y anotaciones geográficas puntuales, como países, posición de Sentinel, 5 km y fechas sincronizadas con la voz.
- Tipografía Anton, mayúsculas blancas, contorno oscuro y énfasis de la palabra clave pronunciada. Grupos de sentido, máximo dos líneas y márgenes seguros.
- Cámara que sigue la acción: canoa → costa; acercamiento desde India; helicóptero visible desde el primer cuadro de su escena; cambios de escala en frases clave; cocos con caída y flotación independientes; cierre que vuelve al encuadre inicial.
- Canoa, helicóptero, rotor, cocos y agua como capas independientes. Congelados breves y flash motivados por fotografía, con el obturador en el mismo fotograma.
- Evitar repetir la isla poligonal centrada: el mapa detallado se reserva para explicar distancia y contexto.
- Sonidos que responden al evento visual del mismo cuadro, con ducking de diálogo. La cantidad de sonidos no demuestra calidad; revisar balance, timings y archivo codificado.
- Voz original preservada en texto, interpretación y ritmo. Mezcla final medida aproximadamente a −16 LUFS y pico verdadero no mayor de −1,5 dBFS.

Los años se presentan numéricamente dentro de los captions, sin rótulos separados que dupliquen la narración. El fondo vertical nuevo de costa evita ampliar las celdas pequeñas del atlas en los planos de canoa/cocos. Pulse solo existe en su intervalo; el helicóptero se mantiene dentro del encuadre y cambia de plano con trayectoria continua. Cocos parcialmente sumergidos, con ondas y salpicaduras breves.
