from pathlib import Path
import json,re,unicodedata
r=Path(__file__).resolve().parent.parent;words=json.loads((r/'public/captions.json').read_text())
script='''Entró en esta isla… | y no regresó | con vida. | Pero las flechas | no son el único peligro. | Esta es | Sentinel del Norte, | una isla de la India, | en el golfo de Bengala. | Desde arriba | parece un paraíso. | Pero la reserva protegida | también incluye | cinco kilómetros | de mar alrededor. | Aquí viven | los sentinelenses, | un pueblo que rechaza | el contacto exterior. | Sabemos tan poco de ellos | que ni siquiera conocemos | cómo se llaman | a sí mismos. | Después del tsunami | de 2004, | un helicóptero se acercó | para comprobar | si habían sobrevivido. | Un habitante fue fotografiado | disparándole flechas | desde la playa. | En dos mil dieciocho, | el misionero estadounidense | John Allen Chau | entró ilegalmente | para intentar evangelizarlos. | Fue asesinado. | Pero hubo | encuentros pacíficos: | en 1991, | algunos sentinelenses | se acercaron a visitantes | y aceptaron cocos. | Entonces… | ¿por qué mantener la distancia? | Porque alguien podría llevar | una infección | sin saberlo. | Enfermedades comunes | fuera de la isla | podrían tener | consecuencias devastadoras | para una comunidad aislada. | La protección también busca | evitar esa amenaza | y respetar | su rechazo al contacto. | Esa playa marca | un límite: | protege a quienes llegan | y a quienes viven allí. | ¿Quién necesita | protección de quién? | Ahora vuelve a mirar | esta isla.'''
def norm(s):return re.sub(r'\W+','',s.lower())
pages=[];pos=0
for phrase in script.split('|'):
 phrase=phrase.strip();ww=phrase.split();matched=words[pos:pos+len(ww)];assert [norm(x['text']) for x in matched]==[norm(x) for x in ww],(phrase,pos,matched)
 pages.append({'text':phrase,'startMs':matched[0]['startMs'],'endMs':matched[-1]['endMs'],'words':matched});pos+=len(ww)
assert pos==len(words)
(r/'src/caption-pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
def stamp(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(r/'out/sentinel-del-norte-v2.srt').write_text('\n'.join(f'{i+1}\n{stamp(p["startMs"])} --> {stamp(p["endMs"])}\n{p["text"].replace("En dos mil dieciocho,", "En 2018,")}\n' for i,p in enumerate(pages)))
print(len(pages),'semantic caption pages,',pos,'aligned words')
