"""Download public-domain Natural Earth source only when rebuilding geography."""
from pathlib import Path
from urllib.request import urlopen
r=Path(__file__).resolve().parent.parent
url='https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_countries.geojson'
p=r/'evidence/countries-10m.json';p.parent.mkdir(exist_ok=True)
with urlopen(url,timeout=60) as response:data=response.read()
p.write_bytes(data);print(p,len(data))
