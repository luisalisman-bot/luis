"""Normalize the rendered audio while copying the approved video stream."""
import subprocess,json,re
from pathlib import Path
r=Path(__file__).resolve().parent.parent;src=r/'out/sentinel-v2-raw.mp4';dst=r/'out/sentinel-del-norte-v2.mp4'
args=['ffmpeg','-hide_banner','-i',str(src),'-vn','-af','loudnorm=I=-16:TP=-2.3:LRA=11:print_format=json','-f','null','-']
a=subprocess.run(args,capture_output=True,text=True,check=True)
measured=json.loads(re.findall(r'\{[^{}]*"input_i"[^{}]*\}',a.stderr)[-1]);(r/'evidence/loudness-input.json').write_text(json.dumps(measured,indent=2))
fil='loudnorm=I=-16:TP=-2.3:LRA=11:linear=true:'+':'.join(f'{k}={measured[v]}' for k,v in [('measured_I','input_i'),('measured_LRA','input_lra'),('measured_TP','input_tp'),('measured_thresh','input_thresh'),('offset','target_offset')])
subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-map','0:v:0','-map','0:a:0','-c:v','copy','-af',fil,'-c:a','aac','-b:a','192k','-ar','48000','-t','76.3','-movflags','+faststart',str(dst)],check=True)
print(dst)
