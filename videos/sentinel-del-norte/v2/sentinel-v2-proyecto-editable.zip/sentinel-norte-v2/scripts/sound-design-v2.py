from pathlib import Path
import numpy as np
from scipy import signal
import wave,json,subprocess
r=Path(__file__).resolve().parent.parent;sr=48000;duration=76.3;n=round(sr*duration);t=np.arange(n)/sr;rng=np.random.default_rng(1126)
# Reserved original score and water; the audible accents follow picture events.
pad=(np.sin(2*np.pi*55*t)*.45+np.sin(2*np.pi*82.4069*t)*.22+np.sin(2*np.pi*110*t)*.12)*(.75+.25*np.sin(t*.43))*.008
music=pad.copy()
for at in np.arange(.3,75,1.6):
 j=round(at*sr);tt=np.arange(min(int(1.1*sr),n-j))/sr
 s=np.sin(2*np.pi*(146.832 if int(at/1.6)%3 else 164.814)*tt)*np.exp(-tt*5)*np.minimum(1,tt/.012)*.003
 music[j:j+len(s)]+=s
music*=np.where((t>=50.9)&(t<53.43),.02,1)
sea=signal.sosfilt(signal.butter(2,[120,2100],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,n))*(.0025+.0017*np.sin(t*.55)**2)
mix=np.column_stack([music+sea,music+sea]);events=[]
def add(frame,kind,gain,pan,label,length=None):
 at=frame/30;length=length or {'zoom':.36,'hit':.52,'arrow':.18,'click':.11,'shutter':.14,'rotor':6.9,'splash':.58,'reverse':.48,'rewind':.4,'tick':.08}.get(kind,.4);tt=np.arange(round(length*sr))/sr;z=rng.normal(0,1,len(tt));env=np.sin(np.pi*tt/length)**2
 if kind=='zoom':s=signal.sosfilt(signal.butter(3,[100,2100],btype='bandpass',fs=sr,output='sos'),z)*env+signal.chirp(tt,160,length,60)*env*.18
 elif kind=='hit':s=(np.sin(2*np.pi*(75*tt-31*tt*tt/length))+.16*np.sin(2*np.pi*162*tt))*np.exp(-tt*9)*np.minimum(1,tt/.007)
 elif kind=='arrow':s=signal.sosfilt(signal.butter(2,[1600,7500],btype='bandpass',fs=sr,output='sos'),z)*env
 elif kind in ['tick','click']:s=(np.sin(2*np.pi*990*tt)*.6+z*.15)*np.exp(-tt*67)*np.minimum(1,tt/.002)
 elif kind=='shutter':s=signal.sosfilt(signal.butter(2,[600,7200],btype='bandpass',fs=sr,output='sos'),z)*(np.exp(-tt*55)+.5*np.exp(-np.maximum(0,tt-.052)*90)*(tt>.052))
 elif kind=='rotor':s=(signal.sosfilt(signal.butter(2,[65,1350],btype='bandpass',fs=sr,output='sos'),z)*.7+.15*np.sin(2*np.pi*87*tt))*(.12+np.maximum(0,np.sin(2*np.pi*(16.5*tt+.06*tt*tt)))**4)*np.minimum(1,tt/.22)*np.minimum(1,(length-tt)/.5)
 elif kind=='splash':s=signal.sosfilt(signal.butter(2,[450,6100],btype='bandpass',fs=sr,output='sos'),z)*np.exp(-tt*8)*np.minimum(1,tt/.006)+np.sin(2*np.pi*(430*tt-220*tt*tt/length))*np.exp(-tt*20)*.6
 elif kind=='reverse':s=signal.sosfilt(signal.butter(2,[180,2200],btype='bandpass',fs=sr,output='sos'),z)*env*(tt/length)
 elif kind=='rewind':s=signal.chirp(tt,1700,length,180)*env*.7
 else:s=z*env
 s=s/(np.max(np.abs(s))+1e-12);j=round(at*sr);m=min(len(s),n-j)
 mix[j:j+m,0]+=s[:m]*gain*np.sqrt((1-pan)/2);mix[j:j+m,1]+=s[:m]*gain*np.sqrt((1+pan)/2)
 events.append({'frame':frame,'second':round(at,4),'type':kind,'gain':gain,'pan':pan,'duration':length,'picture_event':label})
plan=[(0,'zoom',.095,-.2,'entrada sobre canoa'),(3,'hit',.09,0,'primera palabra: entró'),(38,'zoom',.085,.2,'seguimiento de la canoa'),(68,'hit',.12,0,'no regresó: golpe de cámara'),(114,'zoom',.085,-.35,'cambio de perspectiva'),(120,'arrow',.12,.5,'flechas en el gancho'),(160,'reverse',.06,0,'el otro peligro'),(195,'zoom',.13,-.3,'viaje geográfico a India'),(231,'click',.075,0,'India'),(278,'zoom',.10,.35,'aproximación a Andamán'),(319,'click',.075,.15,'localización de Sentinel'),(333,'zoom',.10,.4,'entrada a la costa real'),(390,'zoom',.11,-.3,'salida al perímetro'),(420,'reverse',.075,0,'expansión de la reserva'),(459,'hit',.115,0,'cinco kilómetros y medida'),(525,'zoom',.10,.25,'recorrido por costa oriental'),(590,'click',.06,.4,'barrera de aislamiento'),(660,'zoom',.095,-.25,'entrada al bosque'),(728,'reverse',.06,0,'acercamiento: no conocemos su nombre'),(788,'hit',.085,0,'tsunami: cambio de lugar'),(833,'click',.09,0,'2004 sincronizado con la voz'),(851,'rotor',.075,-.15,'helicóptero visible al pronunciarlo'),(913,'zoom',.08,.2,'seguimiento y acercamiento de helicóptero'),(956,'zoom',.085,-.3,'cambio de plano hacia la costa'),(975,'shutter',.12,0,'fotografiado: flash y congelado'),(998,'arrow',.12,.6,'primera flecha sale de la playa'),(1012,'arrow',.105,.15,'segunda flecha'),(1026,'arrow',.10,-.35,'tercera flecha'),(1010,'hit',.055,0,'reacción del helicóptero'),(1061,'zoom',.12,.3,'regreso al mapa en 2018'),(1079,'click',.09,0,'2018: año pronunciado'),(1138,'zoom',.095,-.25,'entrada a la canoa de la costa'),(1180,'zoom',.085,.2,'entró ilegalmente: seguimiento'),(1265,'hit',.105,0,'fue asesinado: congelado breve'),(1295,'rewind',.10,-.15,'cambio a los encuentros pacíficos'),(1367,'click',.085,0,'1991: año sincronizado'),(1389,'splash',.095,-.4,'primer coco toca agua'),(1452,'zoom',.07,.2,'acercamiento al intercambio'),(1452,'splash',.085,0,'segundo coco toca agua'),(1502,'splash',.10,.35,'tercer coco al agua, aceptaron cocos'),(1527,'reverse',.07,0,'por qué mantener la distancia: retirada de música'),(1603,'hit',.10,0,'entrada al riesgo que puede traer el visitante'),(1643,'zoom',.115,0,'una infección: acercamiento microscópico'),(1697,'zoom',.105,.2,'corte a macro conceptual'),(1745,'tick',.055,-.25,'microorganismo en foco'),(1806,'reverse',.075,.35,'retorno del concepto a la costa'),(1874,'zoom',.105,-.25,'la protección: distancia'),(1927,'click',.075,.35,'trazo que frena el acercamiento'),(2016,'zoom',.105,.2,'recorrido por playa'),(2058,'zoom',.095,.4,'un límite: acercamiento a orilla'),(2121,'zoom',.08,-.2,'retirada desde costa'),(2158,'reverse',.065,0,'pregunta final'),(2226,'zoom',.085,-.2,'regreso a encuadre inicial')]
for a in plan:add(*a)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(r/'public/audio.mp3'),'-f','f32le','-ar',str(sr),'-ac','1','-']);vo=np.frombuffer(raw,np.float32);v=np.zeros(n);v[:min(n,len(vo))]=vo[:n];rms=np.sqrt(np.maximum(0,signal.convolve(v*v,np.ones(1680)/1680,mode='same',method='fft')));mix*=(1-.25*np.clip((rms-.009)/.06,0,1))[:,None]
mix[-9600:]*=np.linspace(1,0,9600)[:,None]
with wave.open(str(r/'public/soundtrack-v2.wav'),'wb') as out:out.setnchannels(2);out.setsampwidth(2);out.setframerate(sr);out.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
(r/'scripts/SOUND_CUES_V2.json').write_text(json.dumps(sorted(events,key=lambda x:x['frame']),ensure_ascii=False,indent=2));print(len(events),'picture-synchronized cues; FX peak',round(20*np.log10(np.max(np.abs(mix))),2),'dBFS')
