import React from 'react';import {AbsoluteFill,Audio,Series,staticFile,useVideoConfig} from 'remotion';import {Fonts} from './Cinema';import {CaptionsV2} from './CaptionsV2';import {HookV2} from './SceneHookV2';import {LocatorV2,ParadiseV2,ReserveV2,IsolationV2,UnknownV2,TsunamiV2} from './SceneMapsV2';import {HelicopterV2,ChauV2,PeaceV2} from './SceneEncountersV2';import {QuestionV2,InvisibleV2,DiseaseV2,ProtectionV2,BeachV2,FinalQuestionV2,LoopV2} from './SceneEndingV2';
export const MainV2=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#073953',fontFamily:'OpenSans',overflow:'hidden'}}><Fonts/><Series>
<Series.Sequence name="Canoa y gancho" durationInFrames={195} premountFor={fps}><HookV2/></Series.Sequence>
<Series.Sequence name="Vuelo desde India a Sentinel" durationInFrames={138} premountFor={fps}><LocatorV2/></Series.Sequence>
<Series.Sequence name="Acercamiento a la costa" durationInFrames={57} premountFor={fps}><ParadiseV2/></Series.Sequence>
<Series.Sequence name="Cinco kilómetros de mar" durationInFrames={135} premountFor={fps}><ReserveV2/></Series.Sequence>
<Series.Sequence name="Costa y aislamiento" durationInFrames={135} premountFor={fps}><IsolationV2/></Series.Sequence>
<Series.Sequence name="Entrada al bosque" durationInFrames={128} premountFor={fps}><UnknownV2/></Series.Sequence>
<Series.Sequence name="Tsunami 2004" durationInFrames={63} premountFor={fps}><TsunamiV2/></Series.Sequence>
<Series.Sequence name="Helicóptero y fotografía" durationInFrames={210} premountFor={fps}><HelicopterV2/></Series.Sequence>
<Series.Sequence name="Chau 2018 y aproximación" durationInFrames={234} premountFor={fps}><ChauV2/></Series.Sequence>
<Series.Sequence name="1991 y cocos al agua" durationInFrames={232} premountFor={fps}><PeaceV2/></Series.Sequence>
<Series.Sequence name="La pregunta" durationInFrames={76} premountFor={fps}><QuestionV2/></Series.Sequence>
<Series.Sequence name="Riesgo que llega desde fuera" durationInFrames={94} premountFor={fps}><InvisibleV2/></Series.Sequence>
<Series.Sequence name="Acercamiento conceptual" durationInFrames={177} premountFor={fps}><DiseaseV2/></Series.Sequence>
<Series.Sequence name="Distancia que protege" durationInFrames={142} premountFor={fps}><ProtectionV2/></Series.Sequence>
<Series.Sequence name="Recorrido por la playa" durationInFrames={142} premountFor={fps}><BeachV2/></Series.Sequence>
<Series.Sequence name="Alejarse de la costa" durationInFrames={68} premountFor={fps}><FinalQuestionV2/></Series.Sequence>
<Series.Sequence name="Bucle al encuadre inicial" durationInFrames={63} premountFor={fps}><LoopV2/></Series.Sequence>
</Series><CaptionsV2/><Audio src={staticFile('audio.mp3')} volume={1}/><Audio src={staticFile('soundtrack-v2.wav')} volume={1}/></AbsoluteFill>};
