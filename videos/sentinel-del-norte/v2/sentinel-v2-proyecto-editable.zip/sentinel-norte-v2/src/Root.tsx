import React from 'react';import {Composition,Still,Folder} from 'remotion';import {MainV2} from './MainV2';import {ThumbnailV2} from './ThumbnailV2';import {HookV2} from './SceneHookV2';import {LocatorV2,ParadiseV2,ReserveV2,IsolationV2,UnknownV2,TsunamiV2} from './SceneMapsV2';import {HelicopterV2,ChauV2,PeaceV2} from './SceneEncountersV2';import {QuestionV2,InvisibleV2,DiseaseV2,ProtectionV2,BeachV2,FinalQuestionV2,LoopV2} from './SceneEndingV2';
export const RemotionRoot=()=> <><Composition id="SentinelV2" component={MainV2} durationInFrames={2289} fps={30} width={1080} height={1920}/><Still id="MiniaturaV2" component={ThumbnailV2} width={1080} height={1440}/><Folder name="EscenasV2">
<Composition id="GanchoV2" component={HookV2} durationInFrames={195} fps={30} width={1080} height={1920}/>
<Composition id="LocalizadorV2" component={LocatorV2} durationInFrames={138} fps={30} width={1080} height={1920}/>
<Composition id="CostaV2" component={ParadiseV2} durationInFrames={57} fps={30} width={1080} height={1920}/>
<Composition id="ReservaV2" component={ReserveV2} durationInFrames={135} fps={30} width={1080} height={1920}/>
<Composition id="AislamientoV2" component={IsolationV2} durationInFrames={135} fps={30} width={1080} height={1920}/>
<Composition id="BosqueV2" component={UnknownV2} durationInFrames={128} fps={30} width={1080} height={1920}/>
<Composition id="TsunamiV2" component={TsunamiV2} durationInFrames={63} fps={30} width={1080} height={1920}/>
<Composition id="HelicopteroV2" component={HelicopterV2} durationInFrames={210} fps={30} width={1080} height={1920}/>
<Composition id="ChauV2" component={ChauV2} durationInFrames={234} fps={30} width={1080} height={1920}/>
<Composition id="EncuentrosV2" component={PeaceV2} durationInFrames={232} fps={30} width={1080} height={1920}/>
<Composition id="PreguntaV2" component={QuestionV2} durationInFrames={76} fps={30} width={1080} height={1920}/>
<Composition id="RiesgoV2" component={InvisibleV2} durationInFrames={94} fps={30} width={1080} height={1920}/>
<Composition id="MacroV2" component={DiseaseV2} durationInFrames={177} fps={30} width={1080} height={1920}/>
<Composition id="ProteccionV2" component={ProtectionV2} durationInFrames={142} fps={30} width={1080} height={1920}/>
<Composition id="PlayaV2" component={BeachV2} durationInFrames={142} fps={30} width={1080} height={1920}/>
<Composition id="PreguntaFinalV2" component={FinalQuestionV2} durationInFrames={68} fps={30} width={1080} height={1920}/>
<Composition id="BucleV2" component={LoopV2} durationInFrames={63} fps={30} width={1080} height={1920}/>
</Folder></>;
